<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Trang người dùng</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f5f7fa;
        }

        .header {
            height: 70px;
            background: #0798f5;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 50px;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        .menu {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .menu a {
            color: white;
            text-decoration: none;
            font-size: 16px;
        }

        .menu a:hover {
            text-decoration: underline;
        }

        .logout {
            background: white;
            color: #0798f5 !important;
            padding: 10px 18px;
            border-radius: 5px;
            font-weight: bold;
        }

        .content {
            width: 90%;
            margin: 40px auto;
            text-align: center;
        }

        .welcome {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .welcome h1 {
            color: #333;
        }

        .welcome p {
            color: #666;
            font-size: 17px;
        }

        .product-button {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 25px;
            background: #0798f5;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>

<body>

    <div class="header">

        <div class="logo">
            SHOPPING SERVICE
        </div>

        <div class="menu">

            <a href="${pageContext.request.contextPath}/product">
                Sản phẩm
            </a>

            <c:if test="${not empty sessionScope.account}">
                <span>
                    Xin chào, ${sessionScope.account.fullName}
                </span>
            </c:if>

            <a class="logout"
               href="${pageContext.request.contextPath}/logout">
                Đăng xuất
            </a>

        </div>

    </div>


    <div class="content">

        <div class="welcome">

            <h1>
                Chào mừng bạn đến với cửa hàng!
            </h1>

            <p>
                Bạn đã đăng nhập thành công với tài khoản người dùng.
            </p>

            <a class="product-button"
               href="${pageContext.request.contextPath}/product">
                Xem sản phẩm
            </a>

        </div>

    </div>

</body>
</html>