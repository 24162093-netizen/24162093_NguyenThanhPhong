<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Danh sách sản phẩm</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background-color: #f5f6fa;
        }

        .header {
            background-color: #0798f5;
            color: white;
            padding: 20px 60px;
        }

        .header h2 {
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
        }

        .title {
            margin-bottom: 25px;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
        }

        .product-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: 0.2s;
        }

        .product-card:hover {
            transform: translateY(-5px);
        }

        .product-image {
            width: 100%;
            height: 220px;
            object-fit: cover;
            border-radius: 8px;
            background-color: #eee;
        }

        .no-image {
            width: 100%;
            height: 220px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #eee;
            border-radius: 8px;
            color: #777;
        }

        .product-name {
            font-size: 20px;
            font-weight: bold;
            margin: 15px 0 8px;
        }

        .product-price {
            color: #e74c3c;
            font-size: 18px;
            font-weight: bold;
        }

        .product-category {
            color: #666;
            margin-top: 8px;
        }

        .detail-button {
            display: block;
            margin-top: 15px;
            padding: 10px;
            text-align: center;
            background-color: #0798f5;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        .detail-button:hover {
            background-color: #087dcc;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 35px;
        }

        .pagination a {
            text-decoration: none;
            padding: 9px 14px;
            border: 1px solid #ddd;
            background: white;
            color: #333;
            border-radius: 5px;
        }

        .pagination a.active {
            background-color: #0798f5;
            color: white;
            border-color: #0798f5;
        }

        .empty {
            background: white;
            padding: 40px;
            text-align: center;
            border-radius: 8px;
        }
    </style>
</head>

<body>

<div class="header">
    <h2>Danh sách sản phẩm</h2>
</div>

<div class="container">

    <div class="title">
        <h2>Tất cả sản phẩm</h2>
    </div>

    <c:choose>

        <c:when test="${not empty products}">

            <div class="product-grid">

                <c:forEach var="product" items="${products}">

                    <div class="product-card">

                        <c:choose>

                            <c:when test="${not empty product.image}">
                                <img class="product-image"
                                     src="${pageContext.request.contextPath}/image?name=${product.image}"
                                     alt="${product.name}">
                            </c:when>

                            <c:otherwise>
                                <div class="no-image">
                                    Chưa có hình ảnh
                                </div>
                            </c:otherwise>

                        </c:choose>

                        <div class="product-name">
                            ${product.name}
                        </div>

                        <div class="product-price">
                            ${product.price} VNĐ
                        </div>

                        <div class="product-category">
                            Danh mục:
                            ${product.category.name}
                        </div>

                        <a class="detail-button"
                           href="${pageContext.request.contextPath}/product/detail?id=${product.id}">
                            Xem chi tiết
                        </a>

                    </div>

                </c:forEach>

            </div>

        </c:when>

        <c:otherwise>

            <div class="empty">
                <h3>Chưa có sản phẩm nào</h3>
            </div>

        </c:otherwise>

    </c:choose>


    <!-- PHÂN TRANG -->

    <c:if test="${totalPages > 1}">

        <div class="pagination">

            <c:if test="${currentPage > 1}">
                <a href="${pageContext.request.contextPath}/product?page=${currentPage - 1}">
                    &laquo;
                </a>
            </c:if>

            <c:forEach begin="1"
                       end="${totalPages}"
                       var="i">

                <a href="${pageContext.request.contextPath}/product?page=${i}"
                   class="${i == currentPage ? 'active' : ''}">
                    ${i}
                </a>

            </c:forEach>

            <c:if test="${currentPage < totalPages}">
                <a href="${pageContext.request.contextPath}/product?page=${currentPage + 1}">
                    &raquo;
                </a>
            </c:if>

        </div>

    </c:if>

</div>

</body>
</html>