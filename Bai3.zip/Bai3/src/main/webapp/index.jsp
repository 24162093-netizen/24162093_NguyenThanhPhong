<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Trang chủ</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f5f7fa;
        }

        .header {
            height: 70px;
            background: #0798f5;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 50px;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        .header a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
        }

        .container {
            width: 90%;
            margin: 35px auto;
        }

        .title {
            text-align: center;
            margin-bottom: 30px;
        }

        .title h2 {
            color: #333;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
        }

        .product-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            transition: 0.2s;
        }

        .product-card:hover {
            transform: translateY(-3px);
        }

        .product-image {
            width: 100%;
            height: 180px;
            object-fit: cover;
            background: #eee;
        }

        .product-info {
            padding: 15px;
        }

        .product-name {
            font-size: 17px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }

        .price {
            color: #e53935;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .detail-button {
            display: inline-block;
            padding: 8px 12px;
            background: #0798f5;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .empty {
            text-align: center;
            color: #777;
            padding: 30px;
        }
    </style>
</head>

<body>

    <div class="header">

        <div class="logo">
            SHOPPING SERVICE
        </div>

        <div>
            
            <a href="${pageContext.request.contextPath}/login">
                Đăng nhập
            </a>
        </div>

    </div>


    <div class="container">

        <div class="title">
            <h2>10 SẢN PHẨM MỚI NHẤT</h2>
             <p style="text-align:center; color:red;">
        Số sản phẩm nhận được: ${products.size()}
    </p>
</div>
        </div>


        <c:choose>

            <c:when test="${not empty products}">

                <div class="product-grid">

                    <c:forEach var="product" items="${products}">

                        <div class="product-card">

                            <c:choose>

                                <c:when test="${not empty product.image}">

                                    <img class="product-image"
                                         src="${pageContext.request.contextPath}/image?name=${product.image}"
                                         alt="${product.name}">

                                </c:when>

                                <c:otherwise>

                                    <div class="product-image"></div>

                                </c:otherwise>

                            </c:choose>


                            <div class="product-info">

                                <div class="product-name">
                                    ${product.name}
                                </div>

                                <div class="price">
                                    ${product.price} VNĐ
                                </div>

                                <a class="detail-button"
                                   href="${pageContext.request.contextPath}/product/detail?id=${product.id}">
                                    Xem chi tiết
                                </a>

                            </div>

                        </div>

                    </c:forEach>

                </div>

            </c:when>

            <c:otherwise>

                <div class="empty">
                    Chưa có sản phẩm nào.
                </div>

            </c:otherwise>

        </c:choose>

    </div>

</body>
</html>