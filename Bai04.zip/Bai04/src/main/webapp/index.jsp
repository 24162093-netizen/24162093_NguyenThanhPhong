<%@ page contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>

<html>

<head>

```
<meta charset="UTF-8">

<title>Trang chủ</title>

<style>

    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background: #f5f7fa;
    }

    /* HEADER */

    .header {
        height: 70px;

        background: #0798f5;

        color: white;

        display: flex;
        align-items: center;
        justify-content: space-between;

        padding: 0 50px;
    }

    .logo {
        font-size: 24px;
        font-weight: bold;
    }

    .login-button {
        color: white;

        text-decoration: none;

        padding: 10px 20px;

        border: 1px solid white;

        border-radius: 5px;

        font-weight: bold;
    }

    .login-button:hover {
        background: white;
        color: #0798f5;
    }

    /* CONTENT */

    .container {
        width: 90%;
        max-width: 1000px;

        margin: 80px auto;

        text-align: center;
    }

    .welcome {
        background: white;

        padding: 60px 40px;

        border-radius: 10px;

        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
    }

    .welcome h1 {
        color: #333;

        margin-bottom: 20px;
    }

    .welcome p {
        color: #666;

        font-size: 18px;

        margin-bottom: 30px;
    }

    .main-login {
        display: inline-block;

        padding: 12px 30px;

        background: #0798f5;

        color: white;

        text-decoration: none;

        border-radius: 5px;

        font-size: 17px;

        font-weight: bold;
    }

    .main-login:hover {
        background: #087dcc;
    }

</style>
```

</head>

<body>

```
<!-- HEADER -->

<div class="header">

    <div class="logo">
        SHOPPING SERVICE
    </div>

    <a class="login-button"
       href="${pageContext.request.contextPath}/login">

        Đăng nhập

    </a>

</div>


<!-- CONTENT -->

<div class="container">

    <div class="welcome">

        <h1>
            Chào mừng bạn đến với Shopping Service
        </h1>

        <p>
            Hệ thống mua sắm trực tuyến
        </p>

        <a class="main-login"
           href="${pageContext.request.contextPath}/login">

            Đăng nhập

        </a>

    </div>

</div>
```

</body>

</html>
