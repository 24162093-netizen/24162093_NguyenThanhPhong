<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${product.name}</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background-color: #f5f6fa;
        }

        .header {
            background-color: #0798f5;
            color: white;
            padding: 20px 60px;
        }

        .header h2 {
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 1100px;
            margin: 40px auto;
        }

        .detail-box {
            display: flex;
            gap: 40px;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .image-area {
            width: 45%;
        }

        .product-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
            border-radius: 8px;
            background-color: #eee;
        }

        .no-image {
            width: 100%;
            height: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #eee;
            border-radius: 8px;
            color: #777;
        }

        .info-area {
            flex: 1;
        }

        .product-name {
            font-size: 30px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .price {
            color: #e74c3c;
            font-size: 25px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .info {
            margin: 15px 0;
            font-size: 17px;
        }

        .description {
            margin-top: 25px;
            line-height: 1.6;
        }

        .back-button {
            display: inline-block;
            margin-top: 25px;
            padding: 10px 20px;
            background-color: #0798f5;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        .back-button:hover {
            background-color: #087dcc;
        }
    </style>
</head>

<body>

<div class="header">
    <h2>Chi tiết sản phẩm</h2>
</div>

<div class="container">

    <div class="detail-box">

        <div class="image-area">

            <c:choose>

                <c:when test="${not empty product.image}">
                    <img class="product-image"
                         src="${pageContext.request.contextPath}/image?name=${product.image}"
                         alt="${product.name}">
                </c:when>

                <c:otherwise>
                    <div class="no-image">
                        Chưa có hình ảnh
                    </div>
                </c:otherwise>

            </c:choose>

        </div>

        <div class="info-area">

            <div class="product-name">
                ${product.name}
            </div>

            <div class="price">
                ${product.price} VNĐ
            </div>

            <div class="info">
                <strong>Số lượng:</strong>
                ${product.quantity}
            </div>

            <div class="info">
                <strong>Danh mục:</strong>
                ${product.category.name}
            </div>

            <div class="description">
                <strong>Mô tả:</strong>
                <p>${product.description}</p>
            </div>

            <a class="back-button"
               href="${pageContext.request.contextPath}/product">
                ← Quay lại sản phẩm
            </a>

        </div>

    </div>

</div>

</body>
</html>