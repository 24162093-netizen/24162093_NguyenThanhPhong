<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa sản phẩm</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }

        .header {
            height: 60px;
            background: #0d6efd;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 25px;
        }

        .header h2 {
            font-size: 21px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logout {
            background: #dc3545;
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
        }

        .sidebar {
            position: fixed;
            top: 60px;
            left: 0;
            width: 220px;
            height: calc(100vh - 60px);
            background: #212529;
            padding-top: 20px;
        }

        .sidebar a {
            display: block;
            color: #ddd;
            text-decoration: none;
            padding: 14px 20px;
            font-size: 15px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #0d6efd;
            color: white;
        }

        .content {
            margin-left: 220px;
            padding: 30px;
        }

        .page-title {
            margin-bottom: 25px;
        }

        .page-title h2 {
            color: #333;
        }

        .form-box {
            background: white;
            width: 700px;
            max-width: 100%;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
            color: #333;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        textarea {
            height: 120px;
            resize: vertical;
        }

        .current-image {
            margin-top: 10px;
        }

        .current-image img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 6px;
            border: 1px solid #ddd;
        }

        .buttons {
            margin-top: 25px;
        }

        .btn-save {
            background: #198754;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 8px;
        }

        .btn-cancel {
            background: #6c757d;
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 5px;
        }

        .alert {
            color: #dc3545;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>

    <!-- HEADER -->
    <div class="header">

        <h2>ADMIN PANEL</h2>

        <div class="user-info">

            <span>
                Xin chào,
                <strong>${sessionScope.account.fullName}</strong>
            </span>

            <a class="logout"
               href="${pageContext.request.contextPath}/logout">
                Đăng xuất
            </a>

        </div>

    </div>

    <!-- SIDEBAR -->
    <div class="sidebar">

        <a href="${pageContext.request.contextPath}/admin/category/list">
            📁 Quản lý danh mục
        </a>

        <a class="active"
           href="${pageContext.request.contextPath}/admin/product/list">
            📦 Quản lý sản phẩm
        </a>

    </div>

    <!-- CONTENT -->
    <div class="content">

        <div class="page-title">
            <h2>Sửa sản phẩm</h2>
        </div>

        <div class="form-box">

            <c:if test="${not empty alert}">
                <div class="alert">
                    ${alert}
                </div>
            </c:if>

            <form action="${pageContext.request.contextPath}/admin/product/edit"
                  method="post">

                <!-- ID -->
                <input type="hidden"
                       name="id"
                       value="${product.id}">

                <!-- TÊN -->
                <div class="form-group">

                    <label>Tên sản phẩm</label>

                    <input type="text"
                           name="name"
                           value="${product.name}"
                           required>

                </div>

                <!-- MÔ TẢ -->
                <div class="form-group">

                    <label>Mô tả</label>

                    <textarea name="description">${product.description}</textarea>

                </div>

                <!-- GIÁ -->
                <div class="form-group">

                    <label>Giá</label>

                    <input type="number"
                           name="price"
                           value="${product.price}"
                           step="0.01"
                           min="0"
                           required>

                </div>

                <!-- SỐ LƯỢNG -->
                <div class="form-group">

                    <label>Số lượng</label>

                    <input type="number"
                           name="quantity"
                           value="${product.quantity}"
                           min="0"
                           required>

                </div>

                <!-- DANH MỤC -->
                <div class="form-group">

                    <label>Danh mục</label>

                    <select name="categoryId" required>

                        <c:forEach var="category" items="${categories}">

                            <option value="${category.id}"
                                ${category.id == product.category.id ? 'selected' : ''}>

                                ${category.name}

                            </option>

                        </c:forEach>

                    </select>

                </div>

                <!-- HÌNH ẢNH -->
                <div class="form-group">

                    <label>Hình ảnh</label>

                    <input type="file"
                           name="image"
                           accept="image/*">

                    <c:if test="${not empty product.image}">

                        <div class="current-image">

                            <p>Ảnh hiện tại:</p>

                            <img src="${pageContext.request.contextPath}/image?name=${product.image}"
                                 alt="${product.name}">

                        </div>

                    </c:if>

                </div>

                <!-- BUTTON -->
                <div class="buttons">

                    <button type="submit"
                            class="btn-save">
                        Cập nhật sản phẩm
                    </button>

                    <a class="btn-cancel"
                       href="${pageContext.request.contextPath}/admin/product/list">
                        Hủy
                    </a>

                </div>

            </form>

        </div>

    </div>

</body>
</html>