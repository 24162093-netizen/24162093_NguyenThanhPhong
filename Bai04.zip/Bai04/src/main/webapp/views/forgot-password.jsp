<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quên mật khẩu</title>
</head>

<body>

    <h2>QUÊN MẬT KHẨU</h2>

    <c:if test="${not empty alert}">
        <p style="color:red;">${alert}</p>
    </c:if>

    <form action="${pageContext.request.contextPath}/forgot-password"
          method="post">

        <div>
            <label>Nhập email:</label>
            <input type="email"
                   name="email"
                   required>
        </div>

        <br>

        <button type="submit">Gửi mã OTP</button>

    </form>

    <br>

    <a href="${pageContext.request.contextPath}/login">
        Quay lại đăng nhập
    </a>

</body>
</html>