<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="vn.entity.User" %>

<!DOCTYPE html>
<html lang="vi">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><sitemesh:write property="title"/></title>

<style>
* {
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    margin: 0;
    background: #f5f7fb;
    color: #333;
}

.topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 30px;
    background: #1976d2;
    color: white;
    border-bottom: 1px solid #ddd;
}

.topbar h1 {
    margin: 0;
    font-size: 22px;
}

.site-title {
    text-decoration: none;
    color: white;
}

.profile-box {
    position: relative;
    display: inline-block;
}

.profile-trigger {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    padding: 6px 10px;
    border-radius: 20px;
}

.profile-trigger:hover {
    background: rgba(255,255,255,0.15);
}

.avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid white;
    background: white;
}

.avatar-placeholder {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: white;
    color: #1976d2;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.profile-name {
    font-weight: 600;
    color: white;
}

.profile-menu {
    display: none;
    position: absolute;
    right: 0;
    top: 52px;
    background: white;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, .15);
    min-width: 190px;
    z-index: 1000;
    overflow: hidden;
}

.profile-box.open .profile-menu {
    display: block;
}

.profile-menu a {
    display: block;
    padding: 10px 16px;
    text-decoration: none;
    color: #333;
}

.profile-menu a:hover {
    background: #f5f5f5;
}

.profile-menu hr {
    margin: 0;
    border: none;
    border-top: 1px solid #eee;
}

.content {
    padding: 30px;
    min-height: calc(100vh - 65px);
}
</style>

<sitemesh:write property="head"/>

</head>

<body>

<%
    User user = (User) session.getAttribute("account");
%>

<div class="topbar">

    <h1>
        <a class="site-title"
           href="<%=request.getContextPath()%>/home">
            SHOPPING SERVICE
        </a>
    </h1>

    <%
        if (user != null) {
    %>

    <div class="profile-box" id="profileBox">

        <div class="profile-trigger"
             onclick="document.getElementById('profileBox').classList.toggle('open')">

            <%
                if (user.getAvatar() != null && !user.getAvatar().isBlank()) {
            %>

                <img class="avatar"
                     src="<%=request.getContextPath()%>/image?name=<%=user.getAvatar()%>"
                     alt="Avatar">

            <%
                } else {

                    String initial = "U";

                    if (user.getFullName() != null
                            && !user.getFullName().isBlank()) {

                        initial = user.getFullName()
                                .substring(0, 1)
                                .toUpperCase();

                    } else if (user.getUserName() != null
                            && !user.getUserName().isBlank()) {

                        initial = user.getUserName()
                                .substring(0, 1)
                                .toUpperCase();
                    }
            %>

                <div class="avatar-placeholder">
                    <%=initial%>
                </div>

            <%
                }
            %>

            <span class="profile-name">

                <%
                    if (user.getFullName() != null
                            && !user.getFullName().isBlank()) {
                %>

                    <%=user.getFullName()%>

                <%
                    } else {
                %>

                    <%=user.getUserName()%>

                <%
                    }
                %>

            </span>

        </div>

        <div class="profile-menu">

            <a href="<%=request.getContextPath()%>/home">
                🏠 Trang chủ
            </a>

            <a href="<%=request.getContextPath()%>/product">
                🛍️ Sản phẩm
            </a>

            <a href="<%=request.getContextPath()%>/profile">
                👤 Hồ sơ cá nhân
            </a>

            <%
                if (user.getRoleid() == 1) {
            %>

                <a href="<%=request.getContextPath()%>/admin/product/list">
                    🛠️ Quản lý Products
                </a>

            <%
                }
            %>

            <hr>

            <a href="<%=request.getContextPath()%>/logout">
                🚪 Đăng xuất
            </a>

        </div>

    </div>

    <%
        } else {
    %>

        <a href="<%=request.getContextPath()%>/login"
           style="color:white; text-decoration:none;">
            Đăng nhập
        </a>

    <%
        }
    %>

</div>

<div class="content">

    <sitemesh:write property="body"/>

</div>

<script>

document.addEventListener('click', function(e) {

    var box = document.getElementById('profileBox');

    if (box && !box.contains(e.target)) {
        box.classList.remove('open');
    }

});

</script>

</body>
</html>