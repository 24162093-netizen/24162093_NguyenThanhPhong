<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Xác nhận OTP</title>
</head>

<body>

    <h2>XÁC NHẬN TÀI KHOẢN</h2>

    <p>
        Mã OTP đã được gửi đến email của bạn.
    </p>

    <c:if test="${not empty alert}">
        <p style="color:red;">${alert}</p>
    </c:if>

    <form action="${pageContext.request.contextPath}/verify-otp" method="post">

        <div>
            <label>Nhập mã OTP:</label>
            <input type="text"
                   name="otp"
                   maxlength="6"
                   required>
        </div>

        <br>

        <button type="submit">Xác nhận</button>

    </form>

</body>
</html>