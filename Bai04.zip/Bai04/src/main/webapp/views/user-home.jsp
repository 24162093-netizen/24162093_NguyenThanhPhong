<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>

<html>

<head>

```
<meta charset="UTF-8">

<title>Trang người dùng</title>

<style>

    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background: #f5f7fa;
    }

    /* ================= HEADER ================= */

    .header {
        height: 70px;
        background: #0798f5;
        color: white;

        display: flex;
        align-items: center;
        justify-content: space-between;

        padding: 0 50px;
    }

    .logo {
        font-size: 24px;
        font-weight: bold;
    }

    .menu {
        display: flex;
        align-items: center;
        gap: 25px;
    }

    .menu > a {
        color: white;
        text-decoration: none;
        font-size: 16px;
    }

    .menu > a:hover {
        text-decoration: underline;
    }

    .menu span {
        font-size: 16px;
    }

    /* ================= AVATAR ================= */

    .avatar-link {
        display: flex;
        align-items: center;
        justify-content: center;

        width: 40px;
        height: 40px;

        text-decoration: none !important;
    }

    .avatar {
        width: 40px;
        height: 40px;

        border-radius: 50%;
        object-fit: cover;

        border: 2px solid white;

        display: block;
    }

    .avatar-default {
        width: 40px;
        height: 40px;

        border-radius: 50%;

        background: white;
        color: #0798f5;

        display: flex;
        align-items: center;
        justify-content: center;

        font-weight: bold;
        font-size: 18px;
    }

    /* ================= LOGOUT ================= */

    .logout {
        background: white;
        color: #0798f5 !important;

        padding: 10px 18px;

        border-radius: 5px;

        font-weight: bold;
    }

    /* ================= CONTENT ================= */

    .content {
        width: 90%;
        max-width: 1200px;

        margin: 40px auto;
    }

    /* ================= WELCOME ================= */

    .welcome {
        background: white;

        padding: 35px;

        border-radius: 10px;

        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

        text-align: center;

        margin-bottom: 35px;
    }

    .welcome h1 {
        color: #333;
        margin-top: 0;
    }

    .welcome p {
        color: #666;
        font-size: 17px;
    }

    /* ================= PRODUCT SECTION ================= */

    .product-section {
        background: white;

        padding: 30px;

        border-radius: 10px;

        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }

    .product-section h2 {
        margin-top: 0;
        margin-bottom: 25px;

        color: #333;
    }

    /* ================= PRODUCT GRID ================= */

    .product-grid {
        display: grid;

        grid-template-columns: repeat(4, 1fr);

        gap: 20px;
    }

    /* ================= PRODUCT CARD ================= */

    .product-card {
        background: white;

        border: 1px solid #eee;

        border-radius: 8px;

        padding: 12px;

        transition: 0.2s;
    }

    .product-card:hover {
        transform: translateY(-5px);

        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.12);
    }

    /* ================= PRODUCT IMAGE ================= */

    .product-image {
        width: 100%;
        height: 180px;

        object-fit: cover;

        border-radius: 6px;

        background: #eee;
    }

    .no-image {
        width: 100%;
        height: 180px;

        display: flex;

        align-items: center;
        justify-content: center;

        background: #eee;

        border-radius: 6px;

        color: #777;
    }

    /* ================= PRODUCT INFO ================= */

    .product-name {
        font-size: 17px;

        font-weight: bold;

        color: #333;

        margin-top: 12px;

        min-height: 40px;
    }

    .product-price {
        color: #e74c3c;

        font-size: 16px;

        font-weight: bold;

        margin-top: 8px;
    }

    /* ================= DETAIL BUTTON ================= */

    .detail-button {
        display: block;

        margin-top: 12px;

        padding: 9px;

        text-align: center;

        background: #0798f5;

        color: white;

        text-decoration: none;

        border-radius: 5px;

        font-size: 14px;
    }

    .detail-button:hover {
        background: #087dcc;
    }

    /* ================= VIEW ALL ================= */

    .view-all {
        text-align: center;

        margin-top: 30px;
    }

    .view-all-button {
        display: inline-block;

        padding: 11px 25px;

        background: #0798f5;

        color: white;

        text-decoration: none;

        border-radius: 5px;

        font-weight: bold;
    }

    .view-all-button:hover {
        background: #087dcc;
    }

    /* ================= EMPTY ================= */

    .empty {
        text-align: center;

        padding: 30px;

        color: #777;
    }

    /* ================= RESPONSIVE ================= */

    @media (max-width: 900px) {

        .product-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .header {
            padding: 0 20px;
        }

    }

    @media (max-width: 600px) {

        .product-grid {
            grid-template-columns: 1fr;
        }

        .logo {
            font-size: 18px;
        }

        .menu {
            gap: 10px;
        }

        .menu span {
            display: none;
        }

    }

</style>
```

</head>

<body>

<!-- ================= HEADER ================= -->

<div class="header">

```
<div class="logo">
    SHOPPING SERVICE
</div>


<div class="menu">

    <a href="${pageContext.request.contextPath}/product">
        Sản phẩm
    </a>


    <c:if test="${not empty sessionScope.account}">

        <span>
            Xin chào, ${sessionScope.account.fullName}
        </span>


        <!-- Avatar -->

        <a class="avatar-link"
           href="${pageContext.request.contextPath}/profile">

            <c:choose>

                <c:when test="${not empty sessionScope.account.avatar}">

                    <img class="avatar"
                         src="${pageContext.request.contextPath}/image?name=${sessionScope.account.avatar}"
                         alt="Avatar">

                </c:when>


                <c:otherwise>

                    <div class="avatar-default">
                        U
                    </div>

                </c:otherwise>

            </c:choose>

        </a>

    </c:if>


    <a class="logout"
       href="${pageContext.request.contextPath}/logout">

        Đăng xuất

    </a>

</div>
```

</div>

<!-- ================= CONTENT ================= -->

<div class="content">

```
<!-- WELCOME -->

<div class="welcome">

    <h1>
        Chào mừng bạn đến với cửa hàng!
    </h1>

    <p>
        Bạn đã đăng nhập thành công với tài khoản người dùng.
    </p>

</div>


<!-- ================= NEW PRODUCTS ================= -->

<div class="product-section">

    <h2>
        Sản phẩm mới nhất
    </h2>


    <c:choose>

        <c:when test="${not empty products}">

            <div class="product-grid">

                <c:forEach var="product"
                           items="${products}">

                    <div class="product-card">


                        <!-- IMAGE -->

                        <c:choose>

                            <c:when test="${not empty product.image}">

                                <img class="product-image"
                                     src="${pageContext.request.contextPath}/image?name=${product.image}"
                                     alt="${product.name}">

                            </c:when>


                            <c:otherwise>

                                <div class="no-image">
                                    Chưa có hình ảnh
                                </div>

                            </c:otherwise>

                        </c:choose>


                        <!-- NAME -->

                        <div class="product-name">

                            ${product.name}

                        </div>


                        <!-- PRICE -->

                        <div class="product-price">

                            ${product.price} VNĐ

                        </div>


                        <!-- DETAIL -->

                        <a class="detail-button"
                           href="${pageContext.request.contextPath}/product/detail?id=${product.id}">

                            Xem chi tiết

                        </a>

                    </div>

                </c:forEach>

            </div>


            <!-- VIEW ALL -->

            <div class="view-all">

                <a class="view-all-button"
                   href="${pageContext.request.contextPath}/product">

                    Xem tất cả sản phẩm

                </a>

            </div>

        </c:when>


        <c:otherwise>

            <div class="empty">

                <h3>
                    Chưa có sản phẩm nào
                </h3>

                <p>
                    Hiện tại cửa hàng chưa có sản phẩm.
                </p>

            </div>

        </c:otherwise>

    </c:choose>

</div>
```

</div>

</body>

</html>
