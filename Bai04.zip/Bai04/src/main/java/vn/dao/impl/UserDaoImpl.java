package vn.dao.impl;

import java.sql.Timestamp;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceException;
import vn.config.JpaConfig;
import vn.dao.UserDao;
import vn.entity.User;

public class UserDaoImpl implements UserDao {

    @Override
    public User findByUsername(String username) {
        EntityManager em = JpaConfig.getEntityManager();

        try {
            String jpql = "SELECT u FROM User u WHERE u.userName = :username";

            return em.createQuery(jpql, User.class)
                    .setParameter("username", username)
                    .getSingleResult();

        } catch (NoResultException e) {
            return null;

        } finally {
            em.close();
        }
    }

    @Override
    public User findByEmail(String email) {
        EntityManager em = JpaConfig.getEntityManager();

        try {
            String jpql = "SELECT u FROM User u WHERE u.email = :email";

            return em.createQuery(jpql, User.class)
                    .setParameter("email", email)
                    .getSingleResult();

        } catch (NoResultException e) {
            return null;

        } finally {
            em.close();
        }
    }

    @Override
    public void register(User user) {
        EntityManager em = JpaConfig.getEntityManager();

        try {
            em.getTransaction().begin();

            em.persist(user);

            em.getTransaction().commit();

        } catch (Exception e) {

            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }

            e.printStackTrace();

        } finally {
            em.close();
        }
    }
    
    @Override
    public void update(User user) {
        EntityManager em = JpaConfig.getEntityManager();

        try {
            em.getTransaction().begin();

            em.merge(user);

            em.getTransaction().commit();

        } catch (Exception e) {

            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }

            e.printStackTrace();

        } finally {
            em.close();
        }
    }
}