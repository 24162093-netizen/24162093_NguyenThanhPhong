package vn.dao.impl;

import java.util.List;

import jakarta.persistence.EntityManager;

import vn.config.JpaConfig;
import vn.dao.ProductDao;
import vn.entity.Product;

public class ProductDaoImpl implements ProductDao {

	@Override
	public List<Product> findAll() {

		EntityManager em = JpaConfig.getEntityManager();

		try {
			String jpql = "SELECT p FROM Product p ORDER BY p.id DESC";

			return em.createQuery(jpql, Product.class).getResultList();

		} finally {
			em.close();
		}
	}
	
	@Override
	public List<Product> findNewest(int limit) {

	    EntityManager em = JpaConfig.getEntityManager();

	    try {
	        String jpql =
	                "SELECT p FROM Product p ORDER BY p.id DESC";

	        return em.createQuery(jpql, Product.class)
	                .setMaxResults(limit)
	                .getResultList();

	    } finally {
	        em.close();
	    }
	}

	@Override
	public List<Product> findPage(int page, int pageSize) {

		EntityManager em = JpaConfig.getEntityManager();

		try {
			String jpql = "SELECT p FROM Product p ORDER BY p.id DESC";

			return em.createQuery(jpql, Product.class).setFirstResult((page - 1) * pageSize).setMaxResults(pageSize)
					.getResultList();

		} finally {
			em.close();
		}
	}

	@Override
	public long count() {

		EntityManager em = JpaConfig.getEntityManager();

		try {
			String jpql = "SELECT COUNT(p) FROM Product p";

			return em.createQuery(jpql, Long.class).getSingleResult();

		} finally {
			em.close();
		}
	}

	@Override
	public Product findById(int id) {

		EntityManager em = JpaConfig.getEntityManager();

		try {
			return em.find(Product.class, id);

		} finally {
			em.close();
		}
	}

	@Override
	public void insert(Product product) {

		EntityManager em = JpaConfig.getEntityManager();

		try {
			em.getTransaction().begin();

			em.persist(product);

			em.getTransaction().commit();

		} catch (Exception e) {

			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}

			e.printStackTrace();

		} finally {
			em.close();
		}
	}

	@Override
	public void update(Product product) {

		EntityManager em = JpaConfig.getEntityManager();

		try {
			em.getTransaction().begin();

			em.merge(product);

			em.getTransaction().commit();

		} catch (Exception e) {

			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}

			e.printStackTrace();

		} finally {
			em.close();
		}
	}

	@Override
	public void delete(int id) {

		EntityManager em = JpaConfig.getEntityManager();

		try {
			em.getTransaction().begin();

			Product product = em.find(Product.class, id);

			if (product != null) {
				em.remove(product);
			}

			em.getTransaction().commit();

		} catch (Exception e) {

			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}

			e.printStackTrace();

		} finally {
			em.close();
		}
	}
}