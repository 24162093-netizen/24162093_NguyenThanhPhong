package vn.dao;

import java.util.List;

import vn.entity.Product;

public interface ProductDao {

    List<Product> findAll();
    
    List<Product> findNewest(int limit);

    List<Product> findPage(int page, int pageSize);

    long count();

    Product findById(int id);

    void insert(Product product);

    void update(Product product);

    void delete(int id);
}