package vn.service.impl;

import java.sql.Timestamp;
import java.util.Random;

import vn.dao.UserDao;
import vn.dao.impl.UserDaoImpl;
import vn.entity.User;
import vn.service.UserService;
import vn.utils.EmailUtil;

public class UserServiceImpl implements UserService {

    private UserDao userDao = new UserDaoImpl();

    @Override
    public User login(String username, String password) {
        User user = userDao.findByUsername(username);

        if (user != null && user.getPassWord().equals(password)) {
            return user;
        }

        return null;
    }

    @Override
    public boolean register(User user) {

        // Kiểm tra username đã tồn tại
        if (userDao.findByUsername(user.getUserName()) != null) {
            return false;
        }

        // Kiểm tra email đã tồn tại
        if (userDao.findByEmail(user.getEmail()) != null) {
            return false;
        }

        // Tạo OTP 6 số
        String otp = String.format("%06d", new Random().nextInt(1000000));

        // Tài khoản chưa kích hoạt
        user.setStatus(0);

        // Lưu OTP
        user.setOtp(otp);

        // OTP có hiệu lực 5 phút
        Timestamp expiry = new Timestamp(
                System.currentTimeMillis() + 5 * 60 * 1000
        );

        user.setOtpExpiry(expiry);

        // Đăng ký vào database
        userDao.register(user);

        // Gửi OTP qua email
        try {
            EmailUtil.sendOTP(user.getEmail(), otp);
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}