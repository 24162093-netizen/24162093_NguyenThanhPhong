package vn.service.impl;

import java.util.List;

import vn.dao.ProductDao;
import vn.dao.impl.ProductDaoImpl;
import vn.entity.Product;
import vn.service.ProductService;

public class ProductServiceImpl implements ProductService {

    private ProductDao productDao = new ProductDaoImpl();

    @Override
    public List<Product> findAll() {
        return productDao.findAll();
    }
    @Override
    public List<Product> findNewest(int limit) {
        return productDao.findNewest(limit);
    }
    @Override
    public List<Product> findPage(int page, int pageSize) {
        return productDao.findPage(page, pageSize);
    }

    @Override
    public long count() {
        return productDao.count();
    }

    @Override
    public Product findById(int id) {
        return productDao.findById(id);
    }

    @Override
    public void insert(Product product) {
        productDao.insert(product);
    }

    @Override
    public void update(Product product) {
        productDao.update(product);
    }

    @Override
    public void delete(int id) {
        productDao.delete(id);
    }
}