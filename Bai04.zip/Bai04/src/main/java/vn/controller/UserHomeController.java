package vn.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.entity.Product;
import vn.service.ProductService;
import vn.service.impl.ProductServiceImpl;

@WebServlet("/user-home")
public class UserHomeController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private ProductService productService = new ProductServiceImpl();

    @Override
    protected void doGet(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        // Lấy 10 sản phẩm mới nhất
        List<Product> products = productService.findNewest(10);

        // Gửi danh sách sản phẩm sang JSP
        req.setAttribute("products", products);

        req.getRequestDispatcher(
                "/views/user-home.jsp"
        ).forward(req, resp);
    }
}