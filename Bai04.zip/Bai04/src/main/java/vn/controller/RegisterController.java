package vn.controller;

import java.io.IOException;
import java.sql.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.entity.User;
import vn.service.UserService;
import vn.service.impl.UserServiceImpl;

@WebServlet("/register")
public class RegisterController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserService userService = new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.getRequestDispatcher("/views/register.jsp")
           .forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        String username = req.getParameter("username");
        String email = req.getParameter("email");
        String fullname = req.getParameter("fullname");
        String password = req.getParameter("password");
        String phone = req.getParameter("phone");

        // Kiểm tra dữ liệu
        if (username == null || username.trim().isEmpty()
                || email == null || email.trim().isEmpty()
                || fullname == null || fullname.trim().isEmpty()
                || password == null || password.trim().isEmpty()) {

            req.setAttribute("alert", "Vui lòng nhập đầy đủ thông tin.");
            req.getRequestDispatcher("/views/register.jsp")
               .forward(req, resp);
            return;
        }

        // Tạo User
        User user = new User();

        user.setUserName(username.trim());
        user.setEmail(email.trim());
        user.setFullName(fullname.trim());
        user.setPassWord(password);
        user.setPhone(phone);
        user.setRoleid(2);
        user.setCreatedDate(new Date(System.currentTimeMillis()));

        // Đăng ký + tạo OTP + gửi email
        boolean success = userService.register(user);

        if (success) {

            // Lưu username vào session để bước xác nhận OTP sử dụng
            req.getSession().setAttribute("verifyUsername", user.getUserName());

            resp.sendRedirect(req.getContextPath() + "/verify-otp");

        } else {

            req.setAttribute(
                "alert",
                "Username hoặc email đã tồn tại, hoặc không thể gửi OTP."
            );

            req.getRequestDispatcher("/views/register.jsp")
               .forward(req, resp);
        }
    }
}