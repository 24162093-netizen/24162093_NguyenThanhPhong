package vn.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Random;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.dao.UserDao;
import vn.dao.impl.UserDaoImpl;
import vn.entity.User;
import vn.utils.EmailUtil;

@WebServlet("/forgot-password")
public class ForgotPasswordController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserDao userDao = new UserDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.getRequestDispatcher("/views/forgot-password.jsp")
           .forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        String email = req.getParameter("email");

        // Kiểm tra email
        if (email == null || email.trim().isEmpty()) {
            req.setAttribute("alert", "Vui lòng nhập email.");
            req.getRequestDispatcher("/views/forgot-password.jsp")
               .forward(req, resp);
            return;
        }

        email = email.trim();

        // Tìm tài khoản theo email
        User user = userDao.findByEmail(email);

        if (user == null) {
            req.setAttribute("alert",
                    "Email chưa được đăng ký trong hệ thống.");
            req.getRequestDispatcher("/views/forgot-password.jsp")
               .forward(req, resp);
            return;
        }

        // Tạo OTP 6 số
        String otp = String.format(
                "%06d",
                new Random().nextInt(1000000)
        );

        // OTP có hiệu lực 5 phút
        Timestamp expiry = new Timestamp(
                System.currentTimeMillis() + 5 * 60 * 1000
        );

        user.setOtp(otp);
        user.setOtpExpiry(expiry);

        userDao.update(user);

        // Gửi OTP qua email
        try {

            EmailUtil.sendOTP(email, otp);

            HttpSession session = req.getSession(true);

            session.setAttribute(
                    "forgotPasswordEmail",
                    email
            );

            resp.sendRedirect(
                    req.getContextPath() + "/forgot-password-otp"
            );

        } catch (Exception e) {

            e.printStackTrace();

            req.setAttribute(
                    "alert",
                    "Không thể gửi OTP. Vui lòng thử lại."
            );

            req.getRequestDispatcher(
                    "/views/forgot-password.jsp"
            ).forward(req, resp);
        }
    }
}