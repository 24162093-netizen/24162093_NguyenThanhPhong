package vn.controller;

import java.io.IOException;
import java.sql.Timestamp;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.dao.UserDao;
import vn.dao.impl.UserDaoImpl;
import vn.entity.User;

@WebServlet("/forgot-password-otp")
public class ForgotPasswordOTPController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserDao userDao = new UserDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);

        if (session == null
                || session.getAttribute("forgotPasswordEmail") == null) {

            resp.sendRedirect(
                    req.getContextPath() + "/forgot-password"
            );
            return;
        }

        req.getRequestDispatcher(
                "/views/forgot-password-otp.jsp"
        ).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        HttpSession session = req.getSession(false);

        if (session == null
                || session.getAttribute("forgotPasswordEmail") == null) {

            resp.sendRedirect(
                    req.getContextPath() + "/forgot-password"
            );
            return;
        }

        String email =
                (String) session.getAttribute("forgotPasswordEmail");

        String otp = req.getParameter("otp");

        if (otp == null || otp.trim().isEmpty()) {

            req.setAttribute(
                    "alert",
                    "Vui lòng nhập mã OTP."
            );

            req.getRequestDispatcher(
                    "/views/forgot-password-otp.jsp"
            ).forward(req, resp);

            return;
        }

        User user = userDao.findByEmail(email);

        if (user == null) {

            req.setAttribute(
                    "alert",
                    "Không tìm thấy tài khoản."
            );

            req.getRequestDispatcher(
                    "/views/forgot-password-otp.jsp"
            ).forward(req, resp);

            return;
        }

        // Kiểm tra OTP
        if (!otp.trim().equals(user.getOtp())) {

            req.setAttribute(
                    "alert",
                    "Mã OTP không đúng."
            );

            req.getRequestDispatcher(
                    "/views/forgot-password-otp.jsp"
            ).forward(req, resp);

            return;
        }

        // Kiểm tra thời gian hết hạn
        Timestamp now =
                new Timestamp(System.currentTimeMillis());

        if (user.getOtpExpiry() == null
                || now.after(user.getOtpExpiry())) {

            req.setAttribute(
                    "alert",
                    "Mã OTP đã hết hạn."
            );

            req.getRequestDispatcher(
                    "/views/forgot-password-otp.jsp"
            ).forward(req, resp);

            return;
        }

        // OTP đúng → cho phép đặt lại mật khẩu
        session.setAttribute(
                "resetPasswordEmail",
                email
        );

        // Xóa OTP cũ
        user.setOtp(null);
        user.setOtpExpiry(null);
        userDao.update(user);

        session.removeAttribute("forgotPasswordEmail");

        resp.sendRedirect(
                req.getContextPath() + "/reset-password"
        );
    }
}