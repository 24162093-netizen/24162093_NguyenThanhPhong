package vn.controller;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import vn.entity.Category;
import vn.entity.Product;
import vn.service.CategoryService;
import vn.service.ProductService;
import vn.service.impl.CategoryServiceImpl;
import vn.service.impl.ProductServiceImpl;
import vn.utils.Constants;

@WebServlet("/admin/product/add")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,
    maxFileSize = 5 * 1024 * 1024,
    maxRequestSize = 10 * 1024 * 1024
)
public class ProductAddController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private CategoryService categoryService = new CategoryServiceImpl();
    private ProductService productService = new ProductServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req,
                         HttpServletResponse resp)
            throws ServletException, IOException {

        List<Category> categories = categoryService.findAll();

        req.setAttribute("categories", categories);

        req.getRequestDispatcher(
            "/views/admin/product/product-add.jsp"
        ).forward(req, resp);
    }

    // Hàm lấy tên file
    private String getFileName(Part part) {

        for (String content :
                part.getHeader("content-disposition").split(";")) {

            if (content.trim().startsWith("filename")) {

                return content.substring(
                    content.indexOf("=") + 2,
                    content.length() - 1
                );
            }
        }

        return Constants.DEFAULT_FILENAME;
    }

    @Override
    protected void doPost(HttpServletRequest req,
                          HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        try {

            // Lấy dữ liệu từ form
            String name = req.getParameter("name");
            String description = req.getParameter("description");
            String priceStr = req.getParameter("price");
            String quantityStr = req.getParameter("quantity");
            String categoryIdStr = req.getParameter("categoryId");

            BigDecimal price = new BigDecimal(priceStr);
            int quantity = Integer.parseInt(quantityStr);
            int categoryId = Integer.parseInt(categoryIdStr);

            // Lấy category
            Category category =
                    categoryService.findById(categoryId);

            // =========================
            // XỬ LÝ FILE ẢNH
            // =========================

            Part imagePart = req.getPart("image");

            String fileName = getFileName(imagePart);

            String uploadPath = getServletContext().getRealPath("")
                    + File.separator
                    + Constants.UPLOAD_DIRECTORY;

            File uploadDir = new File(uploadPath);

            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }
            if (fileName != null
                    && !fileName.isEmpty()
                    && !fileName.equals(Constants.DEFAULT_FILENAME)) {

            	File imageFile = new File(uploadDir, fileName);

            	try (var inputStream = imagePart.getInputStream()) {
            	    java.nio.file.Files.copy(
            	        inputStream,
            	        imageFile.toPath(),
            	        java.nio.file.StandardCopyOption.REPLACE_EXISTING
            	    );
            	}
            }

            // =========================
            // TẠO PRODUCT
            // =========================

            Product product = new Product();

            product.setName(name);
            product.setDescription(description);
            product.setPrice(price);
            product.setQuantity(quantity);
            product.setCategory(category);

            // Lưu tên file vào database
            if (fileName != null
                    && !fileName.isEmpty()
                    && !fileName.equals(Constants.DEFAULT_FILENAME)) {

                product.setImage(fileName);
            }

            // Lưu product vào database
            productService.insert(product);

            // Chuyển về danh sách sản phẩm
            resp.sendRedirect(
                req.getContextPath() + "/admin/product/list"
            );

        } catch (Exception e) {

            e.printStackTrace();

            req.setAttribute(
                "alert",
                "Thêm sản phẩm thất bại!"
            );

            req.getRequestDispatcher(
                "/views/admin/product/product-add.jsp"
            ).forward(req, resp);
        }
    }
}