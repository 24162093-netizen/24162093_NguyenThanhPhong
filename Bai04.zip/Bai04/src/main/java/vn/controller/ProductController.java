package vn.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.entity.Product;
import vn.service.ProductService;
import vn.service.impl.ProductServiceImpl;

@WebServlet("/product")
public class ProductController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private ProductService productService = new ProductServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req,
                          HttpServletResponse resp)
            throws ServletException, IOException {

        int page = 1;
        int pageSize = 6;

        try {
            String pageStr = req.getParameter("page");

            if (pageStr != null) {
                page = Integer.parseInt(pageStr);
            }

        } catch (NumberFormatException e) {
            page = 1;
        }

        long totalProducts = productService.count();

        int totalPages = (int) Math.ceil(
                (double) totalProducts / pageSize
        );

        if (totalPages > 0 && page > totalPages) {
            page = totalPages;
        }

        if (page < 1) {
            page = 1;
        }

        List<Product> products =
                productService.findPage(page, pageSize);

        req.setAttribute("products", products);
        req.setAttribute("currentPage", page);
        req.setAttribute("totalPages", totalPages);

        req.getRequestDispatcher(
                "/views/product.jsp"
        ).forward(req, resp);
    }
}