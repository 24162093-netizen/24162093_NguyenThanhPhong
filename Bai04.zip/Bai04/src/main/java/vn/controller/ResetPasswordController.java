package vn.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.dao.UserDao;
import vn.dao.impl.UserDaoImpl;
import vn.entity.User;

@WebServlet("/reset-password")
public class ResetPasswordController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserDao userDao = new UserDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);

        // Chưa xác nhận OTP → không được đặt lại mật khẩu
        if (session == null
                || session.getAttribute("resetPasswordEmail") == null) {

            resp.sendRedirect(
                    req.getContextPath() + "/forgot-password"
            );
            return;
        }

        req.getRequestDispatcher(
                "/views/reset-password.jsp"
        ).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        HttpSession session = req.getSession(false);

        if (session == null
                || session.getAttribute("resetPasswordEmail") == null) {

            resp.sendRedirect(
                    req.getContextPath() + "/forgot-password"
            );
            return;
        }

        String email =
                (String) session.getAttribute("resetPasswordEmail");

        String password = req.getParameter("password");
        String confirmPassword =
                req.getParameter("confirmPassword");

        // Kiểm tra dữ liệu
        if (password == null
                || password.trim().isEmpty()
                || confirmPassword == null
                || confirmPassword.trim().isEmpty()) {

            req.setAttribute(
                    "alert",
                    "Vui lòng nhập đầy đủ mật khẩu."
            );

            req.getRequestDispatcher(
                    "/views/reset-password.jsp"
            ).forward(req, resp);

            return;
        }

        // Kiểm tra hai mật khẩu
        if (!password.equals(confirmPassword)) {

            req.setAttribute(
                    "alert",
                    "Mật khẩu nhập lại không khớp."
            );

            req.getRequestDispatcher(
                    "/views/reset-password.jsp"
            ).forward(req, resp);

            return;
        }

        // Tìm tài khoản
        User user = userDao.findByEmail(email);

        if (user == null) {

            req.setAttribute(
                    "alert",
                    "Không tìm thấy tài khoản."
            );

            req.getRequestDispatcher(
                    "/views/reset-password.jsp"
            ).forward(req, resp);

            return;
        }

        // Cập nhật mật khẩu mới
        user.setPassWord(password);

        userDao.update(user);

        // Xóa thông tin reset khỏi session
        session.removeAttribute("resetPasswordEmail");

        // Chuyển về trang đăng nhập
        req.setAttribute(
                "alert",
                "Đổi mật khẩu thành công. Vui lòng đăng nhập lại."
        );

        req.getRequestDispatcher(
                "/views/login.jsp"
        ).forward(req, resp);
    }
}