package vn.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.entity.Category;
import vn.entity.Product;
import vn.service.CategoryService;
import vn.service.ProductService;
import vn.service.impl.CategoryServiceImpl;
import vn.service.impl.ProductServiceImpl;

@WebServlet("/admin/product/edit")
public class ProductEditController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private ProductService productService = new ProductServiceImpl();
    private CategoryService categoryService = new CategoryServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req,
                          HttpServletResponse resp)
            throws ServletException, IOException {

        String idStr = req.getParameter("id");

        try {

            int id = Integer.parseInt(idStr);

            Product product = productService.findById(id);

            if (product == null) {
                resp.sendRedirect(
                    req.getContextPath() + "/admin/product/list"
                );
                return;
            }

            List<Category> categories = categoryService.findAll();

            req.setAttribute("product", product);
            req.setAttribute("categories", categories);

            req.getRequestDispatcher(
                "/views/admin/product/product-edit.jsp"
            ).forward(req, resp);

        } catch (Exception e) {

            e.printStackTrace();

            resp.sendRedirect(
                req.getContextPath() + "/admin/product/list"
            );
        }
    }

    @Override
    protected void doPost(HttpServletRequest req,
                           HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        try {

            int id = Integer.parseInt(
                req.getParameter("id")
            );

            String name = req.getParameter("name");
            String description = req.getParameter("description");

            BigDecimal price = new BigDecimal(
                req.getParameter("price")
            );

            int quantity = Integer.parseInt(
                req.getParameter("quantity")
            );

            int categoryId = Integer.parseInt(
                req.getParameter("categoryId")
            );

            Product product = productService.findById(id);

            if (product == null) {
                resp.sendRedirect(
                    req.getContextPath() + "/admin/product/list"
                );
                return;
            }

            Category category = categoryService.findById(categoryId);

            product.setName(name);
            product.setDescription(description);
            product.setPrice(price);
            product.setQuantity(quantity);
            product.setCategory(category);

            productService.update(product);

            resp.sendRedirect(
                req.getContextPath() + "/admin/product/list"
            );

        } catch (Exception e) {

            e.printStackTrace();

            req.setAttribute(
                "alert",
                "Cập nhật sản phẩm thất bại!"
            );

            req.getRequestDispatcher(
                "/views/admin/product/product-list.jsp"
            ).forward(req, resp);
        }
    }
}