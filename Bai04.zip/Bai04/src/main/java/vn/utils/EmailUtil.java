package vn.utils;

import java.util.Properties;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class EmailUtil {

    // THAY bằng email Gmail của bạn
    private static final String FROM_EMAIL = "nguyenthanhphong2000bg@gmail.com";

    // THAY bằng App Password của Gmail
    private static final String APP_PASSWORD = "ihintjvqlskbxtjf";

    public static void sendOTP(String toEmail, String otp) throws Exception {

        Properties props = new Properties();

        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, APP_PASSWORD);
            }
        });

        Message message = new MimeMessage(session);

        message.setFrom(new InternetAddress(FROM_EMAIL));
        message.setRecipients(
                Message.RecipientType.TO,
                InternetAddress.parse(toEmail)
        );

        message.setSubject("Mã OTP kích hoạt tài khoản - Bai02");

        message.setText(
                "Xin chào,\n\n"
                + "Mã OTP của bạn là: " + otp + "\n\n"
                + "Mã OTP có hiệu lực trong 5 phút.\n"
                + "Vui lòng không chia sẻ mã này cho người khác.\n\n"
                + "Trân trọng."
        );

        Transport.send(message);
    }
}