package vn.utils;

public class EmailTest {

    public static void main(String[] args) {
        try {
            EmailUtil.sendOTP(
                "nguyenthanhphong2000bg@gmail.com",
                "123456"
            );

            System.out.println("Gửi email thành công!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}