package vn.controller;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import vn.entity.Category;
import vn.entity.Product;
import vn.service.CategoryService;
import vn.service.ProductService;
import vn.service.impl.CategoryServiceImpl;
import vn.service.impl.ProductServiceImpl;
import vn.utils.Constants;

@WebServlet("/admin/product/edit")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,
    maxFileSize = 5 * 1024 * 1024,
    maxRequestSize = 10 * 1024 * 1024
)
public class ProductEditController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private ProductService productService =
            new ProductServiceImpl();

    private CategoryService categoryService =
            new CategoryServiceImpl();

    @Override
    protected void doGet(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        String idStr = req.getParameter("id");

        try {

            int id = Integer.parseInt(idStr);

            Product product =
                    productService.findById(id);

            if (product == null) {

                resp.sendRedirect(
                        req.getContextPath()
                        + "/admin/product/list"
                );

                return;
            }

            List<Category> categories =
                    categoryService.findAll();

            req.setAttribute(
                    "product",
                    product
            );

            req.setAttribute(
                    "categories",
                    categories
            );

            req.getRequestDispatcher(
                    "/views/admin/product/product-edit.jsp"
            ).forward(req, resp);

        } catch (Exception e) {

            e.printStackTrace();

            resp.sendRedirect(
                    req.getContextPath()
                    + "/admin/product/list"
            );
        }
    }

    @Override
    protected void doPost(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        try {

            // =========================
            // ID
            // =========================

            String idStr =
                    req.getParameter("id");

            if (idStr == null ||
                idStr.trim().isEmpty()) {

                redirectList(req, resp);
                return;
            }

            int id;

            try {

                id = Integer.parseInt(
                        idStr.trim()
                );

            } catch (NumberFormatException e) {

                redirectList(req, resp);
                return;
            }

            Product product =
                    productService.findById(id);

            if (product == null) {

                redirectList(req, resp);
                return;
            }

            // =========================
            // LẤY DỮ LIỆU
            // =========================

            String name =
                    req.getParameter("name");

            String description =
                    req.getParameter("description");

            String priceStr =
                    req.getParameter("price");

            String quantityStr =
                    req.getParameter("quantity");

            String categoryIdStr =
                    req.getParameter("categoryId");

            // =========================
            // VALIDATE TÊN
            // =========================

            if (name == null ||
                name.trim().isEmpty()) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Tên sản phẩm không được để trống."
                );

                return;
            }

            name = name.trim();

            if (name.length() < 2 ||
                name.length() > 255) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Tên sản phẩm phải từ 2 đến 255 ký tự."
                );

                return;
            }

            // =========================
            // VALIDATE GIÁ
            // =========================

            if (priceStr == null ||
                priceStr.trim().isEmpty()) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Giá sản phẩm không được để trống."
                );

                return;
            }

            BigDecimal price;

            try {

                price = new BigDecimal(
                        priceStr.trim()
                );

            } catch (NumberFormatException e) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Giá sản phẩm không hợp lệ."
                );

                return;
            }

            if (price.compareTo(BigDecimal.ZERO) < 0) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Giá sản phẩm không được nhỏ hơn 0."
                );

                return;
            }

            // =========================
            // VALIDATE SỐ LƯỢNG
            // =========================

            if (quantityStr == null ||
                quantityStr.trim().isEmpty()) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Số lượng không được để trống."
                );

                return;
            }

            int quantity;

            try {

                quantity = Integer.parseInt(
                        quantityStr.trim()
                );

            } catch (NumberFormatException e) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Số lượng phải là số nguyên."
                );

                return;
            }

            if (quantity < 0) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Số lượng không được nhỏ hơn 0."
                );

                return;
            }

            // =========================
            // VALIDATE CATEGORY
            // =========================

            if (categoryIdStr == null ||
                categoryIdStr.trim().isEmpty()) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Vui lòng chọn danh mục."
                );

                return;
            }

            int categoryId;

            try {

                categoryId = Integer.parseInt(
                        categoryIdStr.trim()
                );

            } catch (NumberFormatException e) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Danh mục không hợp lệ."
                );

                return;
            }

            if (categoryId <= 0) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Danh mục không hợp lệ."
                );

                return;
            }

            Category category =
                    categoryService.findById(
                            categoryId
                    );

            if (category == null) {

                forwardWithError(
                        req,
                        resp,
                        product,
                        "Danh mục không tồn tại."
                );

                return;
            }

            // =========================
            // XỬ LÝ ẢNH MỚI
            // =========================

            Part imagePart =
                    req.getPart("image");

            if (imagePart != null &&
                imagePart.getSize() > 0) {

                String originalFileName =
                        imagePart.getSubmittedFileName();

                if (originalFileName == null ||
                    originalFileName.isBlank()) {

                    forwardWithError(
                            req,
                            resp,
                            product,
                            "File hình ảnh không hợp lệ."
                    );

                    return;
                }

                String lowerFileName =
                        originalFileName.toLowerCase();

                if (!(lowerFileName.endsWith(".jpg")
                        || lowerFileName.endsWith(".jpeg")
                        || lowerFileName.endsWith(".png")
                        || lowerFileName.endsWith(".gif")
                        || lowerFileName.endsWith(".webp"))) {

                    forwardWithError(
                            req,
                            resp,
                            product,
                            "Chỉ được chọn file ảnh JPG, JPEG, PNG, GIF hoặc WEBP."
                    );

                    return;
                }

                String extension = "";

                int dotIndex =
                        originalFileName.lastIndexOf(".");

                if (dotIndex >= 0) {

                    extension =
                            originalFileName.substring(
                                    dotIndex
                            );
                }

                String fileName =
                        UUID.randomUUID()
                        + extension;

                String uploadPath =
                        getServletContext()
                                .getRealPath("")
                        + File.separator
                        + Constants.UPLOAD_DIRECTORY;

                File uploadDir =
                        new File(uploadPath);

                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }

                File imageFile =
                        new File(
                                uploadDir,
                                fileName
                        );

                imagePart.write(
                        imageFile.getAbsolutePath()
                );

                // Cập nhật ảnh mới
                product.setImage(fileName);
            }

            // =========================
            // CẬP NHẬT PRODUCT
            // =========================

            product.setName(name);
            product.setDescription(description);
            product.setPrice(price);
            product.setQuantity(quantity);
            product.setCategory(category);

            productService.update(product);

            resp.sendRedirect(
                    req.getContextPath()
                    + "/admin/product/list"
            );

        } catch (Exception e) {

            e.printStackTrace();

            req.setAttribute(
                    "alert",
                    "Cập nhật sản phẩm thất bại!"
            );

            req.getRequestDispatcher(
                    "/views/admin/product/product-edit.jsp"
            ).forward(req, resp);
        }
    }

    private void forwardWithError(
            HttpServletRequest req,
            HttpServletResponse resp,
            Product product,
            String message)
            throws ServletException, IOException {

        List<Category> categories =
                categoryService.findAll();

        req.setAttribute(
                "product",
                product
        );

        req.setAttribute(
                "categories",
                categories
        );

        req.setAttribute(
                "alert",
                message
        );

        req.getRequestDispatcher(
                "/views/admin/product/product-edit.jsp"
        ).forward(req, resp);
    }

    private void redirectList(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws IOException {

        resp.sendRedirect(
                req.getContextPath()
                + "/admin/product/list"
        );
    }
}