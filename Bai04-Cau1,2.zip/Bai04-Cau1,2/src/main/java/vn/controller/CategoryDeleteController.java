package vn.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.service.CategoryService;
import vn.service.impl.CategoryServiceImpl;

@WebServlet("/admin/category/delete")
public class CategoryDeleteController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private CategoryService categoryService =
            new CategoryServiceImpl();

    @Override
    protected void doGet(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        String idParam = req.getParameter("id");

        // Kiểm tra id
        if (idParam == null || idParam.trim().isEmpty()) {

            resp.sendRedirect(
                    req.getContextPath()
                    + "/admin/category/list"
            );

            return;
        }

        try {

            int id = Integer.parseInt(idParam);

            // Kiểm tra id phải lớn hơn 0
            if (id <= 0) {

                resp.sendRedirect(
                        req.getContextPath()
                        + "/admin/category/list"
                );

                return;
            }

            categoryService.delete(id);

        } catch (NumberFormatException e) {

            e.printStackTrace();

        } catch (Exception e) {

            e.printStackTrace();
        }

        resp.sendRedirect(
                req.getContextPath()
                + "/admin/category/list"
        );
    }
}