package vn.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.entity.Product;
import vn.service.ProductService;
import vn.service.impl.ProductServiceImpl;

@WebServlet("/product/detail")
public class ProductDetailController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private ProductService productService =
            new ProductServiceImpl();

    @Override
    protected void doGet(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        try {

            String idStr = req.getParameter("id");

            if (idStr == null || idStr.trim().isEmpty()) {
                resp.sendRedirect(
                        req.getContextPath() + "/product"
                );
                return;
            }

            int id = Integer.parseInt(idStr);

            if (id <= 0) {
                resp.sendRedirect(
                        req.getContextPath() + "/product"
                );
                return;
            }

            Product product =
                    productService.findById(id);

            if (product == null) {
                resp.sendRedirect(
                        req.getContextPath() + "/product"
                );
                return;
            }

            req.setAttribute("product", product);

            // Xác định trang người dùng đi tới
            String from = req.getParameter("from");

            if ("admin".equals(from)) {
                req.setAttribute("backUrl",
                        req.getContextPath()
                        + "/admin/product/list");

                req.setAttribute(
                        "backText",
                        "← Quay lại quản lý sản phẩm"
                );

            } else {
                req.setAttribute("backUrl",
                        req.getContextPath()
                        + "/product");

                req.setAttribute(
                        "backText",
                        "← Quay lại sản phẩm"
                );
            }

            req.getRequestDispatcher(
                    "/views/product-detail.jsp"
            ).forward(req, resp);

        } catch (NumberFormatException e) {

            e.printStackTrace();

            resp.sendRedirect(
                    req.getContextPath() + "/product"
            );

        } catch (Exception e) {

            e.printStackTrace();

            resp.sendRedirect(
                    req.getContextPath() + "/product"
            );
        }
    }
}