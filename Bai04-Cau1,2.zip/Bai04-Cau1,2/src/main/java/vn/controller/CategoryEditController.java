package vn.controller;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import vn.entity.Category;
import vn.service.CategoryService;
import vn.service.impl.CategoryServiceImpl;
import vn.utils.Constants;

@MultipartConfig(
    maxFileSize = 5 * 1024 * 1024,
    maxRequestSize = 10 * 1024 * 1024
)
@WebServlet("/admin/category/edit")
public class CategoryEditController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private CategoryService categoryService =
            new CategoryServiceImpl();

    @Override
    protected void doGet(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        try {

            int id = Integer.parseInt(
                    req.getParameter("id")
            );

            Category category =
                    categoryService.findById(id);

            if (category == null) {

                resp.sendRedirect(
                        req.getContextPath()
                        + "/admin/category/list"
                );

                return;
            }

            req.setAttribute(
                    "category",
                    category
            );

            req.getRequestDispatcher(
                    "/views/admin/edit-category.jsp"
            ).forward(req, resp);

        } catch (Exception e) {

            e.printStackTrace();

            resp.sendRedirect(
                    req.getContextPath()
                    + "/admin/category/list"
            );
        }
    }

    @Override
    protected void doPost(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        try {

            int id = Integer.parseInt(
                    req.getParameter("id")
            );

            String name =
                    req.getParameter("name");

            // Tìm category hiện tại
            Category category =
                    categoryService.findById(id);

            if (category == null) {

                resp.sendRedirect(
                        req.getContextPath()
                        + "/admin/category/list"
                );

                return;
            }

            // =========================
            // VALIDATE TÊN
            // =========================

            if (name == null ||
                name.trim().isEmpty()) {

                req.setAttribute(
                        "category",
                        category
                );

                req.setAttribute(
                        "error",
                        "Tên danh mục không được để trống."
                );

                req.getRequestDispatcher(
                        "/views/admin/edit-category.jsp"
                ).forward(req, resp);

                return;
            }

            name = name.trim();

            if (name.length() < 2 ||
                name.length() > 100) {

                req.setAttribute(
                        "category",
                        category
                );

                req.setAttribute(
                        "error",
                        "Tên danh mục phải từ 2 đến 100 ký tự."
                );

                req.getRequestDispatcher(
                        "/views/admin/edit-category.jsp"
                ).forward(req, resp);

                return;
            }

            // =========================
            // XỬ LÝ HÌNH ẢNH
            // =========================

            Part iconPart =
                    req.getPart("icon");

            // Nếu có chọn ảnh mới
            if (iconPart != null &&
                iconPart.getSize() > 0) {

                String originalFileName =
                        iconPart.getSubmittedFileName();

                if (originalFileName == null ||
                    originalFileName.isBlank()) {

                    req.setAttribute(
                            "category",
                            category
                    );

                    req.setAttribute(
                            "error",
                            "File hình ảnh không hợp lệ."
                    );

                    req.getRequestDispatcher(
                            "/views/admin/edit-category.jsp"
                    ).forward(req, resp);

                    return;
                }

                String lowerFileName =
                        originalFileName.toLowerCase();

                if (!(lowerFileName.endsWith(".jpg")
                        || lowerFileName.endsWith(".jpeg")
                        || lowerFileName.endsWith(".png")
                        || lowerFileName.endsWith(".gif")
                        || lowerFileName.endsWith(".webp"))) {

                    req.setAttribute(
                            "category",
                            category
                    );

                    req.setAttribute(
                            "error",
                            "Chỉ được chọn file ảnh JPG, JPEG, PNG, GIF hoặc WEBP."
                    );

                    req.getRequestDispatcher(
                            "/views/admin/edit-category.jsp"
                    ).forward(req, resp);

                    return;
                }

                String extension = "";

                int dotIndex =
                        originalFileName.lastIndexOf(".");

                if (dotIndex >= 0) {
                    extension =
                            originalFileName.substring(dotIndex);
                }

                String fileName =
                        UUID.randomUUID().toString()
                        + extension;

                String uploadPath =
                        getServletContext()
                                .getRealPath("")
                        + File.separator
                        + Constants.UPLOAD_DIRECTORY;

                File uploadDir =
                        new File(uploadPath);

                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }

                File imageFile =
                        new File(uploadDir, fileName);

                iconPart.write(
                        imageFile.getAbsolutePath()
                );

                // Cập nhật tên ảnh mới
                category.setIcon(fileName);
            }

            // =========================
            // CẬP NHẬT CATEGORY
            // =========================

            category.setName(name);

            categoryService.update(category);

            resp.sendRedirect(
                    req.getContextPath()
                    + "/admin/category/list"
            );

        } catch (Exception e) {

            e.printStackTrace();

            resp.sendRedirect(
                    req.getContextPath()
                    + "/admin/category/list"
            );
        }
    }
}