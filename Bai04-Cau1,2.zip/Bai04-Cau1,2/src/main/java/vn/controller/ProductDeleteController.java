package vn.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.service.ProductService;
import vn.service.impl.ProductServiceImpl;

@WebServlet("/admin/product/delete")
public class ProductDeleteController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private ProductService productService =
            new ProductServiceImpl();

    @Override
    protected void doGet(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        String idParam =
                req.getParameter("id");

        // Kiểm tra ID có tồn tại hay không
        if (idParam == null ||
            idParam.trim().isEmpty()) {

            redirectList(req, resp);
            return;
        }

        try {

            int id =
                    Integer.parseInt(
                            idParam.trim()
                    );

            // ID phải lớn hơn 0
            if (id <= 0) {

                redirectList(req, resp);
                return;
            }

            // Kiểm tra sản phẩm có tồn tại
            if (productService.findById(id) == null) {

                redirectList(req, resp);
                return;
            }

            // Xóa sản phẩm
            productService.delete(id);

        } catch (NumberFormatException e) {

            e.printStackTrace();

        } catch (Exception e) {

            e.printStackTrace();
        }

        redirectList(req, resp);
    }

    private void redirectList(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws IOException {

        resp.sendRedirect(
                req.getContextPath()
                + "/admin/product/list"
        );
    }
}