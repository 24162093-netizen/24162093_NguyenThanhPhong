package vn.controller;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import vn.entity.Category;
import vn.service.CategoryService;
import vn.service.impl.CategoryServiceImpl;
import vn.utils.Constants;

@MultipartConfig(
    maxFileSize = 5 * 1024 * 1024,
    maxRequestSize = 10 * 1024 * 1024
)
@WebServlet("/admin/category/add")
public class CategoryAddController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private CategoryService categoryService =
            new CategoryServiceImpl();

    @Override
    protected void doGet(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        req.getRequestDispatcher(
                "/views/admin/add-category.jsp"
        ).forward(req, resp);
    }

    @Override
    protected void doPost(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        // =========================
        // 1. LẤY TÊN DANH MỤC
        // =========================

        String name = req.getParameter("name");

        if (name == null || name.trim().isEmpty()) {

            req.setAttribute(
                    "error",
                    "Tên danh mục không được để trống."
            );

            req.getRequestDispatcher(
                    "/views/admin/add-category.jsp"
            ).forward(req, resp);

            return;
        }

        name = name.trim();

        // Kiểm tra độ dài tên
        if (name.length() < 2 || name.length() > 100) {

            req.setAttribute(
                    "error",
                    "Tên danh mục phải từ 2 đến 100 ký tự."
            );

            req.getRequestDispatcher(
                    "/views/admin/add-category.jsp"
            ).forward(req, resp);

            return;
        }


        // =========================
        // 2. LẤY FILE HÌNH ẢNH
        // =========================

        Part iconPart = req.getPart("icon");

        if (iconPart == null || iconPart.getSize() == 0) {

            req.setAttribute(
                    "error",
                    "Vui lòng chọn hình ảnh."
            );

            req.getRequestDispatcher(
                    "/views/admin/add-category.jsp"
            ).forward(req, resp);

            return;
        }


        String originalFileName =
                iconPart.getSubmittedFileName();


        if (originalFileName == null ||
            originalFileName.isBlank()) {

            req.setAttribute(
                    "error",
                    "File hình ảnh không hợp lệ."
            );

            req.getRequestDispatcher(
                    "/views/admin/add-category.jsp"
            ).forward(req, resp);

            return;
        }


        // =========================
        // 3. KIỂM TRA ĐỊNH DẠNG ẢNH
        // =========================

        String lowerFileName =
                originalFileName.toLowerCase();

        if (!(lowerFileName.endsWith(".jpg")
                || lowerFileName.endsWith(".jpeg")
                || lowerFileName.endsWith(".png")
                || lowerFileName.endsWith(".gif")
                || lowerFileName.endsWith(".webp"))) {

            req.setAttribute(
                    "error",
                    "Chỉ được chọn file ảnh JPG, JPEG, PNG, GIF hoặc WEBP."
            );

            req.getRequestDispatcher(
                    "/views/admin/add-category.jsp"
            ).forward(req, resp);

            return;
        }


        // =========================
        // 4. TẠO TÊN FILE MỚI
        // =========================

        String extension = "";

        int dotIndex =
                originalFileName.lastIndexOf(".");

        if (dotIndex >= 0) {

            extension =
                    originalFileName.substring(dotIndex);
        }

        String fileName =
                UUID.randomUUID().toString()
                + extension;


        // =========================
        // 5. TẠO THƯ MỤC UPLOADS
        // =========================

        String uploadPath =
                getServletContext()
                        .getRealPath("")
                + File.separator
                + Constants.UPLOAD_DIRECTORY;

        File uploadDir =
                new File(uploadPath);

        if (!uploadDir.exists()) {

            uploadDir.mkdirs();
        }


        // =========================
        // 6. LƯU FILE
        // =========================

        File imageFile =
                new File(uploadDir, fileName);

        iconPart.write(
                imageFile.getAbsolutePath()
        );


        // =========================
        // 7. TẠO CATEGORY
        // =========================

        Category category =
                new Category();

        category.setName(name);

        category.setIcon(fileName);


        // =========================
        // 8. LƯU DATABASE
        // =========================

        categoryService.insert(category);


        // =========================
        // 9. CHUYỂN VỀ DANH SÁCH
        // =========================

        resp.sendRedirect(
                req.getContextPath()
                + "/admin/category/list"
        );
    }
}