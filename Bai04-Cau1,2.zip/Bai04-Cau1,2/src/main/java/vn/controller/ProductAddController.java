package vn.controller;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import vn.entity.Category;
import vn.entity.Product;
import vn.service.CategoryService;
import vn.service.ProductService;
import vn.service.impl.CategoryServiceImpl;
import vn.service.impl.ProductServiceImpl;
import vn.utils.Constants;

@WebServlet("/admin/product/add")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,
    maxFileSize = 5 * 1024 * 1024,
    maxRequestSize = 10 * 1024 * 1024
)
public class ProductAddController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private CategoryService categoryService =
            new CategoryServiceImpl();

    private ProductService productService =
            new ProductServiceImpl();

    @Override
    protected void doGet(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        List<Category> categories =
                categoryService.findAll();

        req.setAttribute(
                "categories",
                categories
        );

        req.getRequestDispatcher(
                "/views/admin/product/product-add.jsp"
        ).forward(req, resp);
    }

    private String getFileName(Part part) {

        if (part == null) {
            return null;
        }

        String submittedFileName =
                part.getSubmittedFileName();

        if (submittedFileName == null ||
            submittedFileName.isBlank()) {

            return null;
        }

        return new File(
                submittedFileName
        ).getName();
    }

    private boolean isValidImage(String fileName) {

        if (fileName == null ||
            fileName.isBlank()) {

            return false;
        }

        String lowerFileName =
                fileName.toLowerCase();

        return lowerFileName.endsWith(".jpg")
                || lowerFileName.endsWith(".jpeg")
                || lowerFileName.endsWith(".png")
                || lowerFileName.endsWith(".gif")
                || lowerFileName.endsWith(".webp");
    }

    @Override
    protected void doPost(
            HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        try {

            // =========================
            // LẤY DỮ LIỆU FORM
            // =========================

            String name =
                    req.getParameter("name");

            String description =
                    req.getParameter("description");

            String priceStr =
                    req.getParameter("price");

            String quantityStr =
                    req.getParameter("quantity");

            String categoryIdStr =
                    req.getParameter("categoryId");

            // =========================
            // VALIDATION TÊN
            // =========================

            if (name == null ||
                name.trim().isEmpty()) {

                setErrorAndForward(
                        req,
                        resp,
                        "Tên sản phẩm không được để trống."
                );

                return;
            }

            name = name.trim();

            if (name.length() < 2 ||
                name.length() > 255) {

                setErrorAndForward(
                        req,
                        resp,
                        "Tên sản phẩm phải từ 2 đến 255 ký tự."
                );

                return;
            }

            // =========================
            // VALIDATION GIÁ
            // =========================

            if (priceStr == null ||
                priceStr.trim().isEmpty()) {

                setErrorAndForward(
                        req,
                        resp,
                        "Giá sản phẩm không được để trống."
                );

                return;
            }

            BigDecimal price;

            try {

                price =
                        new BigDecimal(
                                priceStr.trim()
                        );

            } catch (NumberFormatException e) {

                setErrorAndForward(
                        req,
                        resp,
                        "Giá sản phẩm không hợp lệ."
                );

                return;
            }

            if (price.compareTo(BigDecimal.ZERO) < 0) {

                setErrorAndForward(
                        req,
                        resp,
                        "Giá sản phẩm không được nhỏ hơn 0."
                );

                return;
            }

            // =========================
            // VALIDATION SỐ LƯỢNG
            // =========================

            if (quantityStr == null ||
                quantityStr.trim().isEmpty()) {

                setErrorAndForward(
                        req,
                        resp,
                        "Số lượng không được để trống."
                );

                return;
            }

            int quantity;

            try {

                quantity =
                        Integer.parseInt(
                                quantityStr.trim()
                        );

            } catch (NumberFormatException e) {

                setErrorAndForward(
                        req,
                        resp,
                        "Số lượng phải là số nguyên."
                );

                return;
            }

            if (quantity < 0) {

                setErrorAndForward(
                        req,
                        resp,
                        "Số lượng không được nhỏ hơn 0."
                );

                return;
            }

            // =========================
            // VALIDATION CATEGORY
            // =========================

            if (categoryIdStr == null ||
                categoryIdStr.trim().isEmpty()) {

                setErrorAndForward(
                        req,
                        resp,
                        "Vui lòng chọn danh mục."
                );

                return;
            }

            int categoryId;

            try {

                categoryId =
                        Integer.parseInt(
                                categoryIdStr.trim()
                        );

            } catch (NumberFormatException e) {

                setErrorAndForward(
                        req,
                        resp,
                        "Danh mục không hợp lệ."
                );

                return;
            }

            if (categoryId <= 0) {

                setErrorAndForward(
                        req,
                        resp,
                        "Danh mục không hợp lệ."
                );

                return;
            }

            Category category =
                    categoryService.findById(
                            categoryId
                    );

            if (category == null) {

                setErrorAndForward(
                        req,
                        resp,
                        "Danh mục không tồn tại."
                );

                return;
            }

            // =========================
            // XỬ LÝ ẢNH
            // =========================

            Part imagePart =
                    req.getPart("image");

            String originalFileName =
                    getFileName(imagePart);

            if (imagePart == null ||
                imagePart.getSize() == 0 ||
                originalFileName == null) {

                setErrorAndForward(
                        req,
                        resp,
                        "Vui lòng chọn hình ảnh."
                );

                return;
            }

            if (!isValidImage(originalFileName)) {

                setErrorAndForward(
                        req,
                        resp,
                        "Chỉ được chọn file ảnh JPG, JPEG, PNG, GIF hoặc WEBP."
                );

                return;
            }

            // =========================
            // TẠO TÊN FILE MỚI
            // =========================

            String extension = "";

            int dotIndex =
                    originalFileName.lastIndexOf(".");

            if (dotIndex >= 0) {

                extension =
                        originalFileName.substring(
                                dotIndex
                        );
            }

            String fileName =
                    UUID.randomUUID()
                    + extension;

            // =========================
            // LƯU FILE
            // =========================

            String uploadPath =
                    getServletContext()
                            .getRealPath("")
                    + File.separator
                    + Constants.UPLOAD_DIRECTORY;

            File uploadDir =
                    new File(uploadPath);

            if (!uploadDir.exists()) {

                uploadDir.mkdirs();
            }

            File imageFile =
                    new File(
                            uploadDir,
                            fileName
                    );

            imagePart.write(
                    imageFile.getAbsolutePath()
            );

            // =========================
            // TẠO PRODUCT
            // =========================

            Product product =
                    new Product();

            product.setName(name);
            product.setDescription(description);
            product.setPrice(price);
            product.setQuantity(quantity);
            product.setCategory(category);
            product.setImage(fileName);

            // =========================
            // LƯU DATABASE
            // =========================

            productService.insert(product);

            resp.sendRedirect(
                    req.getContextPath()
                    + "/admin/product/list"
            );

        } catch (Exception e) {

            e.printStackTrace();

            setErrorAndForward(
                    req,
                    resp,
                    "Thêm sản phẩm thất bại!"
            );
        }
    }

    private void setErrorAndForward(
            HttpServletRequest req,
            HttpServletResponse resp,
            String message)
            throws ServletException, IOException {

        List<Category> categories =
                categoryService.findAll();

        req.setAttribute(
                "categories",
                categories
        );

        req.setAttribute(
                "alert",
                message
        );

        req.getRequestDispatcher(
                "/views/admin/product/product-add.jsp"
        ).forward(req, resp);
    }
}