package vn.controller;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import vn.dao.UserDao;
import vn.dao.impl.UserDaoImpl;
import vn.entity.User;
import vn.utils.Constants;

@MultipartConfig
@WebServlet("/profile")
public class ProfileController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserDao userDao = new UserDaoImpl();

    // =========================
    // HIỂN THỊ PROFILE
    // =========================
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);

        if (session == null || session.getAttribute("account") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("account");

        req.setAttribute("user", user);

        req.getRequestDispatcher("/views/profile.jsp")
           .forward(req, resp);
    }

    // =========================
    // CẬP NHẬT PROFILE
    // =========================
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        HttpSession session = req.getSession(false);

        // Kiểm tra đăng nhập
        if (session == null || session.getAttribute("account") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Lấy user đang đăng nhập
        User user = (User) session.getAttribute("account");

        // =========================
        // 1. LẤY FULLNAME + PHONE
        // =========================
        String fullName = req.getParameter("fullName");
        String phone = req.getParameter("phone");

        fullName = fullName != null ? fullName.trim() : "";
        phone = phone != null ? phone.trim() : "";

        // Kiểm tra Họ và tên
        if (fullName.isEmpty()) {

            req.setAttribute("alert",
                    "Họ và tên không được để trống.");

            req.setAttribute("user", user);

            req.getRequestDispatcher("/views/profile.jsp")
               .forward(req, resp);

            return;
        }

        if (fullName.length() < 2 || fullName.length() > 100) {

            req.setAttribute("alert",
                    "Họ và tên phải từ 2 đến 100 ký tự.");

            req.setAttribute("user", user);

            req.getRequestDispatcher("/views/profile.jsp")
               .forward(req, resp);

            return;
        }

        // Kiểm tra Số điện thoại
        if (!phone.matches("^[0-9]{10,11}$")) {

            req.setAttribute("alert",
                    "Số điện thoại phải gồm 10 hoặc 11 chữ số.");

            req.setAttribute("user", user);

            req.getRequestDispatcher("/views/profile.jsp")
               .forward(req, resp);

            return;
        }

        // Dữ liệu hợp lệ
        user.setFullName(fullName);
        user.setPhone(phone);

        // =========================
        // 2. XỬ LÝ AVATAR
        // =========================

        Part avatarPart = req.getPart("avatar");

        if (avatarPart != null && avatarPart.getSize() > 0) {

            String originalFileName = avatarPart.getSubmittedFileName();

            if (originalFileName != null && !originalFileName.isBlank()) {

                // Lấy phần mở rộng file
                String extension = "";

                int dotIndex = originalFileName.lastIndexOf(".");

                if (dotIndex >= 0) {
                    extension = originalFileName.substring(dotIndex);
                }

                // Tạo tên file mới để tránh trùng
                String fileName = UUID.randomUUID().toString() + extension;

                // Thư mục uploads
                String uploadPath = getServletContext()
                        .getRealPath("")
                        + File.separator
                        + Constants.UPLOAD_DIRECTORY;

                File uploadDir = new File(uploadPath);

                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }

                // Lưu file
                File imageFile = new File(uploadDir, fileName);

                avatarPart.write(imageFile.getAbsolutePath());

                // Lưu tên file vào User
                user.setAvatar(fileName);
            }
        }

        // =========================
        // 3. LƯU DATABASE
        // =========================

        userDao.update(user);

        // Cập nhật user trong session
        session.setAttribute("account", user);

        // Quay lại profile
        resp.sendRedirect(req.getContextPath() + "/profile");
    }
}