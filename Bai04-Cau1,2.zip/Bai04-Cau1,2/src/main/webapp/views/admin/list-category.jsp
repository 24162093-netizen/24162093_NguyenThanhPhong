<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<!DOCTYPE html>
<html lang="vi">

<head>

<meta charset="UTF-8">

<title>Quản lý danh mục</title>

<style>
body {
	background-color: #f5f7fb;
}

.category-container {
	max-width: 1200px;
	margin: 30px auto;
	background: white;
	padding: 30px;
	border-radius: 10px;
	box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
}

.category-title {
	font-weight: 700;
	margin-bottom: 25px;
}

.action-link {
	text-decoration: none;
	margin-right: 8px;
}

.empty {
	text-align: center;
	padding: 30px;
	color: #888;
}
</style>

</head>

<body>

	<div class="category-container">

		<div class="d-flex justify-content-between align-items-center mb-4">

			<h2 class="category-title mb-0">QUẢN LÝ DANH MỤC</h2>

			<div>

				<a class="btn btn-primary me-2"
					href="${pageContext.request.contextPath}/admin/category/add"> +
					Thêm danh mục </a> <a class="btn btn-success"
					href="${pageContext.request.contextPath}/admin/product/list">

					📦 Quản lý sản phẩm </a>

			</div>

		</div>


		<div class="table-responsive">

			<table class="table table-bordered table-hover align-middle">

				<thead class="table-light">

					<tr>

						<th class="text-center" style="width: 100px;">ID</th>

						<th>Tên danh mục</th>

						<th>Icon</th>

						<th class="text-center" style="width: 180px;">Hành động</th>

					</tr>

				</thead>

				<tbody>

					<c:choose>

						<c:when test="${not empty cateList}">

							<c:forEach items="${cateList}" var="cate">

								<tr>

									<td class="text-center">${cate.id}</td>

									<td>${cate.name}</td>

									<td><c:if test="${not empty cate.icon}">
											<img
												src="${pageContext.request.contextPath}/image?name=${cate.icon}"
												alt="${cate.name}"
												style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px;">
										</c:if></td>

									<td class="text-center"><a
										class="btn btn-sm btn-warning action-link"
										href="${pageContext.request.contextPath}/admin/category/edit?id=${cate.id}">

											Sửa </a> <a class="btn btn-sm btn-danger action-link"
										href="${pageContext.request.contextPath}/admin/category/delete?id=${cate.id}"
										onclick="return confirm('Bạn có chắc chắn muốn xóa danh mục này không?');">

											Xóa </a></td>

								</tr>

							</c:forEach>

						</c:when>

						<c:otherwise>

							<tr>

								<td colspan="4" class="empty">Chưa có danh mục nào.</td>

							</tr>

						</c:otherwise>

					</c:choose>

				</tbody>

			</table>

		</div>

	</div>

</body>

</html>