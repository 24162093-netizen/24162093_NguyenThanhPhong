<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Sửa danh mục</title>

    <style>
        .category-form {
            max-width: 600px;
            margin: 40px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        }

        .category-form h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        .form-group input[type="text"],
        .form-group input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 15px;
        }

        .form-group input:focus {
            outline: none;
            border-color: #0798f5;
        }

        .current-image {
            margin-top: 10px;
        }

        .current-image img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid #ddd;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 5px;
        }

        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            font-size: 15px;
        }

        .btn-save {
            background: #0798f5;
            color: white;
        }

        .btn-save:hover {
            background: #057dcc;
        }

        .btn-back {
            background: #eeeeee;
            color: #333;
        }

        .btn-back:hover {
            background: #dddddd;
        }
    </style>
</head>

<body>

<div class="category-form">

    <h2>SỬA DANH MỤC</h2>

    <c:if test="${not empty error}">
        <p style="color:red;">
            ${error}
        </p>
    </c:if>

    <form
        action="${pageContext.request.contextPath}/admin/category/edit"
        method="post"
        enctype="multipart/form-data"
        onsubmit="return validateCategory()">

        <input
            type="hidden"
            name="id"
            value="${category.id}">

        <!-- Tên danh mục -->
        <div class="form-group">

            <label for="name">
                Tên danh mục:
            </label>

            <input
                type="text"
                id="name"
                name="name"
                value="${category.name}"
                required
                minlength="2"
                maxlength="100"
                placeholder="Nhập tên danh mục">

            <div
                id="nameError"
                class="error-message">
            </div>

        </div>

        <!-- Hình ảnh hiện tại -->
        <div class="form-group">

            <label>
                Hình ảnh hiện tại:
            </label>

            <div class="current-image">

                <c:if test="${not empty category.icon}">

                    <img
                        src="${pageContext.request.contextPath}/image?name=${category.icon}"
                        alt="${category.name}">

                </c:if>

            </div>

        </div>

        <!-- Upload hình ảnh mới -->
        <div class="form-group">

            <label for="icon">
                Chọn hình ảnh mới:
            </label>

            <input
                type="file"
                id="icon"
                name="icon"
                accept="image/*">

            <div
                id="iconError"
                class="error-message">
            </div>

            <small>
                Nếu không chọn ảnh mới thì hình ảnh hiện tại sẽ được giữ nguyên.
            </small>

        </div>

        <!-- Button -->
        <div class="button-group">

            <button
                type="submit"
                class="btn btn-save">
                Lưu thay đổi
            </button>

            <a
                href="${pageContext.request.contextPath}/admin/category/list"
                class="btn btn-back">
                Quay lại
            </a>

        </div>

    </form>

</div>

<script>

function validateCategory() {

    let valid = true;

    let name =
        document.getElementById("name").value.trim();

    let icon =
        document.getElementById("icon");

    document.getElementById("nameError").innerHTML = "";
    document.getElementById("iconError").innerHTML = "";

    // Kiểm tra tên danh mục
    if (name.length < 2 || name.length > 100) {

        document.getElementById("nameError").innerHTML =
            "Tên danh mục phải từ 2 đến 100 ký tự.";

        valid = false;
    }

    // Nếu có chọn ảnh mới thì kiểm tra ảnh
    if (icon.files.length > 0) {

        let file = icon.files[0];

        let fileName =
            file.name.toLowerCase();

        let allowedExtensions =
            [".jpg", ".jpeg", ".png", ".gif", ".webp"];

        let isImage = false;

        for (let i = 0; i < allowedExtensions.length; i++) {

            if (fileName.endsWith(allowedExtensions[i])) {

                isImage = true;
                break;
            }
        }

        if (!isImage) {

            document.getElementById("iconError").innerHTML =
                "Chỉ được chọn file ảnh JPG, JPEG, PNG, GIF hoặc WEBP.";

            valid = false;
        }

        // Kiểm tra dung lượng tối đa 5MB
        if (file.size > 5 * 1024 * 1024) {

            document.getElementById("iconError").innerHTML =
                "Kích thước hình ảnh không được vượt quá 5MB.";

            valid = false;
        }
    }

    return valid;
}

</script>

</body>
</html>