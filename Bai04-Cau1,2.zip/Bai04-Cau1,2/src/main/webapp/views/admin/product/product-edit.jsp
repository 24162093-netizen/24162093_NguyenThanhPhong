<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">

<head>

    <meta charset="UTF-8">

    <title>Sửa sản phẩm</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }

        .header {
            height: 60px;
            background: #0d6efd;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 25px;
        }

        .header h2 {
            font-size: 21px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logout {
            background: #dc3545;
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
        }

        .sidebar {
            position: fixed;
            top: 60px;
            left: 0;
            width: 220px;
            height: calc(100vh - 60px);
            background: #212529;
            padding-top: 20px;
        }

        .sidebar a {
            display: block;
            color: #ddd;
            text-decoration: none;
            padding: 14px 20px;
            font-size: 15px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #0d6efd;
            color: white;
        }

        .content {
            margin-left: 220px;
            padding: 30px;
        }

        .page-title {
            margin-bottom: 25px;
        }

        .page-title h2 {
            color: #333;
        }

        .form-box {
            background: white;
            width: 700px;
            max-width: 100%;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
            color: #333;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        textarea {
            height: 120px;
            resize: vertical;
        }

        .error {
            color: #dc3545;
            font-size: 13px;
            margin-top: 5px;
        }

        .current-image {
            margin-top: 10px;
        }

        .current-image img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 6px;
            border: 1px solid #ddd;
        }

        .note {
            color: #6c757d;
            font-size: 13px;
            margin-top: 5px;
        }

        .buttons {
            margin-top: 25px;
        }

        .btn-save {
            background: #198754;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 8px;
        }

        .btn-cancel {
            background: #6c757d;
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 5px;
        }

        .alert {
            color: #dc3545;
            margin-bottom: 15px;
        }

    </style>

</head>

<body>

    <!-- HEADER -->

    <div class="header">

        <h2>ADMIN PANEL</h2>

        <div class="user-info">

            <span>
                Xin chào,
                <strong>${sessionScope.account.fullName}</strong>
            </span>

            <a class="logout"
               href="${pageContext.request.contextPath}/logout">
                Đăng xuất
            </a>

        </div>

    </div>


    <!-- SIDEBAR -->

    <div class="sidebar">

        <a href="${pageContext.request.contextPath}/admin/category/list">
            📁 Quản lý danh mục
        </a>

        <a class="active"
           href="${pageContext.request.contextPath}/admin/product/list">
            📦 Quản lý sản phẩm
        </a>

    </div>


    <!-- CONTENT -->

    <div class="content">

        <div class="page-title">
            <h2>Sửa sản phẩm</h2>
        </div>


        <div class="form-box">

            <!-- SERVER ERROR -->

            <c:if test="${not empty alert}">

                <div class="alert">
                    ${alert}
                </div>

            </c:if>


            <!-- FORM -->

            <form
                action="${pageContext.request.contextPath}/admin/product/edit"
                method="post"
                enctype="multipart/form-data"
                onsubmit="return validateProductEdit();">


                <!-- ID -->

                <input
                    type="hidden"
                    name="id"
                    value="${product.id}">


                <!-- TÊN -->

                <div class="form-group">

                    <label for="name">
                        Tên sản phẩm
                    </label>

                    <input
                        type="text"
                        id="name"
                        name="name"
                        value="${product.name}"
                        minlength="2"
                        maxlength="255"
                        required>

                    <div id="nameError" class="error"></div>

                </div>


                <!-- MÔ TẢ -->

                <div class="form-group">

                    <label for="description">
                        Mô tả
                    </label>

                    <textarea
                        id="description"
                        name="description">${product.description}</textarea>

                </div>


                <!-- GIÁ -->

                <div class="form-group">

                    <label for="price">
                        Giá
                    </label>

                    <input
                        type="number"
                        id="price"
                        name="price"
                        value="${product.price}"
                        step="0.01"
                        min="0"
                        required>

                    <div id="priceError" class="error"></div>

                </div>


                <!-- SỐ LƯỢNG -->

                <div class="form-group">

                    <label for="quantity">
                        Số lượng
                    </label>

                    <input
                        type="number"
                        id="quantity"
                        name="quantity"
                        value="${product.quantity}"
                        min="0"
                        step="1"
                        required>

                    <div id="quantityError" class="error"></div>

                </div>


                <!-- DANH MỤC -->

                <div class="form-group">

                    <label for="categoryId">
                        Danh mục
                    </label>

                    <select
                        id="categoryId"
                        name="categoryId"
                        required>

                        <option value="">
                            -- Chọn danh mục --
                        </option>

                        <c:forEach
                            var="category"
                            items="${categories}">

                            <option
                                value="${category.id}"
                                ${category.id == product.category.id ? 'selected' : ''}>

                                ${category.name}

                            </option>

                        </c:forEach>

                    </select>

                    <div id="categoryError" class="error"></div>

                </div>


                <!-- HÌNH ẢNH -->

                <div class="form-group">

                    <label for="image">
                        Hình ảnh
                    </label>

                    <input
                        type="file"
                        id="image"
                        name="image"
                        accept="image/*">

                    <div class="note">
                        Nếu không chọn ảnh mới, hệ thống sẽ giữ ảnh hiện tại.
                    </div>

                    <div id="imageError" class="error"></div>


                    <!-- ẢNH HIỆN TẠI -->

                    <c:if test="${not empty product.image}">

                        <div class="current-image">

                            <p>Ảnh hiện tại:</p>

                            <img
                                src="${pageContext.request.contextPath}/image?name=${product.image}"
                                alt="${product.name}">

                        </div>

                    </c:if>

                </div>


                <!-- BUTTON -->

                <div class="buttons">

                    <button
                        type="submit"
                        class="btn-save">

                        Cập nhật sản phẩm

                    </button>

                    <a
                        class="btn-cancel"
                        href="${pageContext.request.contextPath}/admin/product/list">

                        Hủy

                    </a>

                </div>

            </form>

        </div>

    </div>


    <!-- JAVASCRIPT VALIDATION -->

    <script>

        function validateProductEdit() {

            let valid = true;


            // Xóa lỗi cũ

            document.getElementById("nameError").innerText = "";
            document.getElementById("priceError").innerText = "";
            document.getElementById("quantityError").innerText = "";
            document.getElementById("categoryError").innerText = "";
            document.getElementById("imageError").innerText = "";


            // =========================
            // TÊN
            // =========================

            const name =
                document.getElementById("name").value.trim();

            if (name === "") {

                document.getElementById("nameError").innerText =
                    "Tên sản phẩm không được để trống.";

                valid = false;

            } else if (name.length < 2 || name.length > 255) {

                document.getElementById("nameError").innerText =
                    "Tên sản phẩm phải từ 2 đến 255 ký tự.";

                valid = false;
            }


            // =========================
            // GIÁ
            // =========================

            const price =
                document.getElementById("price").value;

            if (price === "") {

                document.getElementById("priceError").innerText =
                    "Giá sản phẩm không được để trống.";

                valid = false;

            } else if (Number(price) < 0) {

                document.getElementById("priceError").innerText =
                    "Giá sản phẩm không được nhỏ hơn 0.";

                valid = false;
            }


            // =========================
            // SỐ LƯỢNG
            // =========================

            const quantity =
                document.getElementById("quantity").value;

            if (quantity === "") {

                document.getElementById("quantityError").innerText =
                    "Số lượng không được để trống.";

                valid = false;

            } else if (!Number.isInteger(Number(quantity))
                       || Number(quantity) < 0) {

                document.getElementById("quantityError").innerText =
                    "Số lượng phải là số nguyên không âm.";

                valid = false;
            }


            // =========================
            // DANH MỤC
            // =========================

            const category =
                document.getElementById("categoryId").value;

            if (category === "") {

                document.getElementById("categoryError").innerText =
                    "Vui lòng chọn danh mục.";

                valid = false;
            }


            // =========================
            // HÌNH ẢNH
            // =========================

            const image =
                document.getElementById("image");

            if (image.files.length > 0) {

                const file =
                    image.files[0];

                const fileName =
                    file.name.toLowerCase();

                const allowedExtensions =
                    [".jpg", ".jpeg", ".png", ".gif", ".webp"];

                const validExtension =
                    allowedExtensions.some(
                        extension =>
                            fileName.endsWith(extension)
                    );

                if (!validExtension) {

                    document.getElementById("imageError").innerText =
                        "Chỉ được chọn file ảnh JPG, JPEG, PNG, GIF hoặc WEBP.";

                    valid = false;

                } else if (file.size > 5 * 1024 * 1024) {

                    document.getElementById("imageError").innerText =
                        "Kích thước ảnh không được vượt quá 5MB.";

                    valid = false;
                }
            }


            return valid;
        }

    </script>

</body>

</html>