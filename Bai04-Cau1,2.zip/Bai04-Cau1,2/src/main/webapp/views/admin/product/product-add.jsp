<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">

<head>

    <meta charset="UTF-8">

    <title>Thêm sản phẩm</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }

        .header {
            height: 60px;
            background: #0d6efd;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 25px;
        }

        .header h2 {
            font-size: 21px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logout {
            background: #dc3545;
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
        }

        .sidebar {
            position: fixed;
            top: 60px;
            left: 0;
            width: 220px;
            height: calc(100vh - 60px);
            background: #212529;
            padding-top: 20px;
        }

        .sidebar a {
            display: block;
            color: #ddd;
            text-decoration: none;
            padding: 14px 20px;
            font-size: 15px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #0d6efd;
            color: white;
        }

        .content {
            margin-left: 220px;
            padding: 30px;
        }

        .page-title {
            margin-bottom: 25px;
        }

        .page-title h2 {
            color: #333;
        }

        .form-box {
            background: white;
            width: 700px;
            max-width: 100%;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
            color: #333;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        textarea {
            height: 120px;
            resize: vertical;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 5px;
        }

        .alert {
            color: red;
            margin-bottom: 15px;
        }

        .buttons {
            margin-top: 25px;
        }

        .btn-save {
            background: #198754;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 8px;
        }

        .btn-cancel {
            background: #6c757d;
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 5px;
        }

        .btn-save:hover {
            background: #157347;
        }

        .btn-cancel:hover {
            background: #5c636a;
        }

    </style>

</head>

<body>

    <!-- HEADER -->

    <div class="header">

        <h2>ADMIN PANEL</h2>

        <div class="user-info">

            <span>
                Xin chào,
                <strong>${sessionScope.account.fullName}</strong>
            </span>

            <a
                class="logout"
                href="${pageContext.request.contextPath}/logout">
                Đăng xuất
            </a>

        </div>

    </div>


    <!-- SIDEBAR -->

    <div class="sidebar">

        <a
            href="${pageContext.request.contextPath}/admin/category/list">
            📁 Quản lý danh mục
        </a>

        <a
            class="active"
            href="${pageContext.request.contextPath}/admin/product/list">
            📦 Quản lý sản phẩm
        </a>

    </div>


    <!-- CONTENT -->

    <div class="content">

        <div class="page-title">

            <h2>Thêm sản phẩm</h2>

        </div>


        <div class="form-box">

            <c:if test="${not empty alert}">

                <div class="alert">
                    ${alert}
                </div>

            </c:if>


            <form
                action="${pageContext.request.contextPath}/admin/product/add"
                method="post"
                enctype="multipart/form-data"
                onsubmit="return validateProduct()">


                <!-- TÊN -->

                <div class="form-group">

                    <label for="name">
                        Tên sản phẩm
                    </label>

                    <input
                        type="text"
                        id="name"
                        name="name"
                        placeholder="Nhập tên sản phẩm"
                        required
                        minlength="2"
                        maxlength="255">

                    <div
                        id="nameError"
                        class="error-message">
                    </div>

                </div>


                <!-- MÔ TẢ -->

                <div class="form-group">

                    <label for="description">
                        Mô tả
                    </label>

                    <textarea
                        id="description"
                        name="description"
                        placeholder="Nhập mô tả sản phẩm">
                    </textarea>

                </div>


                <!-- GIÁ -->

                <div class="form-group">

                    <label for="price">
                        Giá
                    </label>

                    <input
                        type="number"
                        id="price"
                        name="price"
                        step="0.01"
                        min="0"
                        placeholder="Nhập giá sản phẩm"
                        required>

                    <div
                        id="priceError"
                        class="error-message">
                    </div>

                </div>


                <!-- SỐ LƯỢNG -->

                <div class="form-group">

                    <label for="quantity">
                        Số lượng
                    </label>

                    <input
                        type="number"
                        id="quantity"
                        name="quantity"
                        min="0"
                        placeholder="Nhập số lượng"
                        required>

                    <div
                        id="quantityError"
                        class="error-message">
                    </div>

                </div>


                <!-- DANH MỤC -->

                <div class="form-group">

                    <label for="categoryId">
                        Danh mục
                    </label>

                    <select
                        id="categoryId"
                        name="categoryId"
                        required>

                        <option value="">
                            -- Chọn danh mục --
                        </option>

                        <c:forEach
                            var="category"
                            items="${categories}">

                            <option value="${category.id}">
                                ${category.name}
                            </option>

                        </c:forEach>

                    </select>

                    <div
                        id="categoryError"
                        class="error-message">
                    </div>

                </div>


                <!-- HÌNH ẢNH -->

                <div class="form-group">

                    <label for="image">
                        Hình ảnh
                    </label>

                    <input
                        type="file"
                        id="image"
                        name="image"
                        accept="image/*"
                        required>

                    <div
                        id="imageError"
                        class="error-message">
                    </div>

                </div>


                <!-- BUTTON -->

                <div class="buttons">

                    <button
                        type="submit"
                        class="btn-save">
                        Lưu sản phẩm
                    </button>

                    <a
                        class="btn-cancel"
                        href="${pageContext.request.contextPath}/admin/product/list">
                        Hủy
                    </a>

                </div>

            </form>

        </div>

    </div>


    <!-- VALIDATION -->

    <script>

        function validateProduct() {

            let valid = true;

            let name =
                document.getElementById("name").value.trim();

            let price =
                document.getElementById("price").value.trim();

            let quantity =
                document.getElementById("quantity").value.trim();

            let category =
                document.getElementById("categoryId").value;

            let image =
                document.getElementById("image");


            // Xóa lỗi cũ

            document.getElementById("nameError").innerHTML = "";
            document.getElementById("priceError").innerHTML = "";
            document.getElementById("quantityError").innerHTML = "";
            document.getElementById("categoryError").innerHTML = "";
            document.getElementById("imageError").innerHTML = "";


            // =========================
            // TÊN
            // =========================

            if (name.length < 2 || name.length > 255) {

                document.getElementById("nameError").innerHTML =
                    "Tên sản phẩm phải từ 2 đến 255 ký tự.";

                valid = false;
            }


            // =========================
            // GIÁ
            // =========================

            if (price === "") {

                document.getElementById("priceError").innerHTML =
                    "Giá sản phẩm không được để trống.";

                valid = false;

            } else if (Number(price) < 0) {

                document.getElementById("priceError").innerHTML =
                    "Giá sản phẩm không được nhỏ hơn 0.";

                valid = false;
            }


            // =========================
            // SỐ LƯỢNG
            // =========================

            if (quantity === "") {

                document.getElementById("quantityError").innerHTML =
                    "Số lượng không được để trống.";

                valid = false;

            } else if (
                !Number.isInteger(Number(quantity)) ||
                Number(quantity) < 0
            ) {

                document.getElementById("quantityError").innerHTML =
                    "Số lượng phải là số nguyên không âm.";

                valid = false;
            }


            // =========================
            // DANH MỤC
            // =========================

            if (category === "") {

                document.getElementById("categoryError").innerHTML =
                    "Vui lòng chọn danh mục.";

                valid = false;
            }


            // =========================
            // HÌNH ẢNH
            // =========================

            if (image.files.length === 0) {

                document.getElementById("imageError").innerHTML =
                    "Vui lòng chọn hình ảnh.";

                valid = false;

            } else {

                let file = image.files[0];

                let fileName =
                    file.name.toLowerCase();

                let allowedExtensions =
                    [".jpg", ".jpeg", ".png", ".gif", ".webp"];

                let isImage = false;

                for (
                    let i = 0;
                    i < allowedExtensions.length;
                    i++
                ) {

                    if (
                        fileName.endsWith(
                            allowedExtensions[i]
                        )
                    ) {

                        isImage = true;
                        break;
                    }
                }

                if (!isImage) {

                    document.getElementById("imageError").innerHTML =
                        "Chỉ được chọn file ảnh JPG, JPEG, PNG, GIF hoặc WEBP.";

                    valid = false;
                }

                if (file.size > 5 * 1024 * 1024) {

                    document.getElementById("imageError").innerHTML =
                        "Kích thước hình ảnh không được vượt quá 5MB.";

                    valid = false;
                }
            }


            return valid;
        }

    </script>

</body>

</html>