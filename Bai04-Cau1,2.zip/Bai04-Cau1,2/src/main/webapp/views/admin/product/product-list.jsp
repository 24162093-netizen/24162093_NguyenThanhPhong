<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>

<html lang="vi">

<head>

    <meta charset="UTF-8">

    <title>Quản lý sản phẩm</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background-color: #f5f5f5;
        }

        /* ================= HEADER ================= */

        .product-header {
            height: 70px;
            background-color: #0798f5;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
        }

        .product-header-title {
            font-size: 28px;
            font-weight: bold;
        }

        .product-header-right {
            display: flex;
            align-items: center;
            gap: 20px;
            font-size: 15px;
        }

        .product-logout {
            background-color: #ff4b4b;
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 5px;
        }

        .product-logout:hover {
            background-color: #d93636;
        }

        /* ================= CONTENT ================= */

        .product-content {
            margin: 30px auto;
            width: 90%;
            background-color: white;
            padding: 30px;
            min-height: 500px;
        }

        .product-title {
            color: #111;
            margin-bottom: 30px;
        }

        /* ================= BUTTON ================= */

        .product-add-button,
        .product-view-button {
            display: inline-block;
            margin-bottom: 25px;
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 5px;
        }

        .product-add-button {
            background-color: #0798f5;
        }

        .product-add-button:hover {
            background-color: #087fc9;
        }

        .product-view-button {
            background-color: #198754;
            margin-left: 8px;
        }

        .product-view-button:hover {
            background-color: #146c43;
        }

        /* ================= TABLE ================= */

        .product-table {
            width: 100%;
            border-collapse: collapse;
        }

        .product-table th,
        .product-table td {
            border: 1px solid #ddd;
            padding: 12px;
        }

        .product-table th {
            background-color: #eeeeee;
            text-align: center;
        }

        .product-table td:first-child {
            text-align: center;
            width: 70px;
        }

        /* ================= IMAGE ================= */

        .product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
        }

        /* ================= ACTION ================= */

        .product-action {
            text-decoration: none;
            margin-right: 8px;
        }

        .product-detail {
            color: #198754;
        }

        .product-edit {
            color: #0798f5;
        }

        .product-delete {
            color: #ff4b4b;
        }

        .product-action:hover {
            text-decoration: underline;
        }

        /* ================= EMPTY ================= */

        .product-empty {
            text-align: center;
            padding: 30px;
            color: #888;
        }

    </style>

</head>

<body>


    <!-- ================= HEADER ================= -->

    <div class="product-header">

        <div class="product-header-title">
            ADMIN
        </div>

        <div class="product-header-right">

            <span>
                Xin chào,
                <b>${sessionScope.account.fullName}</b>
            </span>

            <a
                class="product-logout"
                href="${pageContext.request.contextPath}/logout"
                onclick="return confirm('Bạn có chắc chắn muốn đăng xuất không?');">

                Đăng xuất

            </a>

        </div>

    </div>


    <!-- ================= CONTENT ================= -->

    <div class="product-content">

        <h2 class="product-title">
            QUẢN LÝ SẢN PHẨM
        </h2>


        <!-- THÊM SẢN PHẨM -->

        <a
            class="product-add-button"
            href="${pageContext.request.contextPath}/admin/product/add">

            + Thêm sản phẩm

        </a>


        <!-- XEM TRANG SẢN PHẨM -->

        <a
            class="product-view-button"
            href="${pageContext.request.contextPath}/product">

            👁 Xem trang sản phẩm

        </a>


        <!-- ================= TABLE ================= -->

        <table class="product-table">

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Hình ảnh</th>

                    <th>Tên sản phẩm</th>

                    <th>Giá</th>

                    <th>Số lượng</th>

                    <th>Danh mục</th>

                    <th>Hành động</th>

                </tr>

            </thead>


            <tbody>

                <c:choose>

                    <c:when test="${not empty products}">

                        <c:forEach
                            var="product"
                            items="${products}">

                            <tr>

                                <!-- ID -->

                                <td>
                                    ${product.id}
                                </td>


                                <!-- HÌNH ẢNH -->

                                <td>

                                    <c:if test="${not empty product.image}">

                                        <img
                                            class="product-image"
                                            src="${pageContext.request.contextPath}/image?name=${product.image}"
                                            alt="${product.name}">

                                    </c:if>

                                </td>


                                <!-- TÊN -->

                                <td>
                                    ${product.name}
                                </td>


                                <!-- GIÁ -->

                                <td>
                                    ${product.price}
                                </td>


                                <!-- SỐ LƯỢNG -->

                                <td>
                                    ${product.quantity}
                                </td>


                                <!-- DANH MỤC -->

                                <td>

                                    <c:choose>

                                        <c:when test="${not empty product.category}">
                                            ${product.category.name}
                                        </c:when>

                                        <c:otherwise>
                                            Chưa có danh mục
                                        </c:otherwise>

                                    </c:choose>

                                </td>


                                <!-- HÀNH ĐỘNG -->

                                <td>

                                    <!-- XEM CHI TIẾT -->

                                    <a
                                        class="product-action product-detail"
                                        href="${pageContext.request.contextPath}/product/detail?id=${product.id}&from=admin">

                                        Xem chi tiết

                                    </a>

                                    |

                                    <!-- SỬA -->

                                    <a
                                        class="product-action product-edit"
                                        href="${pageContext.request.contextPath}/admin/product/edit?id=${product.id}">

                                        Sửa

                                    </a>

                                    |

                                    <!-- XÓA -->

                                    <a
                                        class="product-action product-delete"
                                        href="${pageContext.request.contextPath}/admin/product/delete?id=${product.id}"
                                        onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này không?');">

                                        Xóa

                                    </a>

                                </td>

                            </tr>

                        </c:forEach>

                    </c:when>


                    <c:otherwise>

                        <tr>

                            <td
                                colspan="7"
                                class="product-empty">

                                Chưa có sản phẩm nào.

                            </td>

                        </tr>

                    </c:otherwise>

                </c:choose>

            </tbody>

        </table>

    </div>

</body>

</html>