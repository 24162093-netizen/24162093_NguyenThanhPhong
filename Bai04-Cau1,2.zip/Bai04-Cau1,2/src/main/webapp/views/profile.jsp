<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html lang="vi">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Hồ sơ cá nhân</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f5f7fa;
        }

        /* Khung profile */

        .profile-container {
            max-width: 600px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        /* Nút quay lại */

        .back-button {
            display: inline-block;
            margin-bottom: 15px;
            padding: 8px 15px;
            background: #eeeeee;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
        }

        .back-button:hover {
            background: #dddddd;
        }

        /* Tiêu đề */

        .profile-container h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        /* Avatar */

        .avatar-preview {
            text-align: center;
            margin-bottom: 25px;
        }

        .avatar-preview img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #0798f5;
        }

        .avatar-placeholder {
            width: 120px;
            height: 120px;
            margin: auto;
            border-radius: 50%;
            background: #0798f5;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 45px;
            font-weight: bold;
        }

        /* Form */

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
            color: #333;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 15px;
        }

        .form-group input:focus {
            outline: none;
            border-color: #0798f5;
        }

        .form-group input[readonly] {
            background: #f3f3f3;
            cursor: not-allowed;
        }

        /* Thông báo lỗi */

        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 5px;
        }

        /* Nút cập nhật */

        .btn-update {
            width: 100%;
            padding: 12px;
            background: #0798f5;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }

        .btn-update:hover {
            background: #057dcc;
        }

    </style>

</head>

<body>

<%

    vn.entity.User user =
            (vn.entity.User) request.getAttribute("user");

%>


<div class="profile-container">


    <!-- Nút quay lại -->

    <a class="back-button"
       href="<%=request.getContextPath()%>/user-home">

        ← Quay lại

    </a>


    <!-- Tiêu đề -->

    <h2>
        Hồ sơ cá nhân
    </h2>


    <!-- Avatar -->

    <div class="avatar-preview">

        <%

            if (user != null
                    && user.getAvatar() != null
                    && !user.getAvatar().isBlank()) {

        %>

            <img
                src="<%=request.getContextPath()%>/image?name=<%=user.getAvatar()%>"
                alt="Avatar">

        <%

            } else {

                String initial = "U";

                if (user != null
                        && user.getFullName() != null
                        && !user.getFullName().isBlank()) {

                    initial = user.getFullName()
                            .substring(0, 1)
                            .toUpperCase();

                } else if (user != null
                        && user.getUserName() != null
                        && !user.getUserName().isBlank()) {

                    initial = user.getUserName()
                            .substring(0, 1)
                            .toUpperCase();

                }

        %>

            <div class="avatar-placeholder">

                <%=initial%>

            </div>

        <%

            }

        %>

    </div>


    <!-- Form cập nhật -->

    <form
        action="<%=request.getContextPath()%>/profile"
        method="post"
        enctype="multipart/form-data"
        onsubmit="return validateProfile()">


        <!-- Username -->

        <div class="form-group">

            <label>
                Username
            </label>

            <input
                type="text"
                value="<%=user.getUserName()%>"
                readonly>

        </div>


        <!-- Email -->

        <div class="form-group">

            <label>
                Email
            </label>

            <input
                type="email"
                value="<%=user.getEmail()%>"
                readonly>

        </div>


        <!-- Fullname -->

        <div class="form-group">

            <label>
                Họ và tên
            </label>

            <input
                type="text"
                name="fullName"
                value="<%=user.getFullName() != null
                        ? user.getFullName()
                        : ""%>"
                required
                minlength="2"
                maxlength="100">

            <div
                id="fullNameError"
                class="error-message">
            </div>

        </div>


        <!-- Phone -->

        <div class="form-group">

            <label>
                Số điện thoại
            </label>

            <input
                type="text"
                name="phone"
                value="<%=user.getPhone() != null
                        ? user.getPhone()
                        : ""%>"
                required>

            <div
                id="phoneError"
                class="error-message">
            </div>

        </div>


        <!-- Avatar -->

        <div class="form-group">

            <label>
                Ảnh đại diện
            </label>

            <input
                type="file"
                name="avatar"
                accept="image/*">

        </div>


        <!-- Button -->

        <button
            type="submit"
            class="btn-update">

            Cập nhật hồ sơ

        </button>

    </form>


</div>


<script>

    function validateProfile() {

        let valid = true;

        let fullName =
            document.querySelector(
                'input[name="fullName"]'
            ).value.trim();

        let phone =
            document.querySelector(
                'input[name="phone"]'
            ).value.trim();


        // Xóa lỗi cũ

        document.getElementById(
            "fullNameError"
        ).innerHTML = "";

        document.getElementById(
            "phoneError"
        ).innerHTML = "";


        // Kiểm tra họ tên

        if (fullName.length < 2 ||
            fullName.length > 100) {

            document.getElementById(
                "fullNameError"
            ).innerHTML =
                "Họ và tên phải từ 2 đến 100 ký tự.";

            valid = false;
        }


        // Kiểm tra số điện thoại

        if (!/^[0-9]{10,11}$/.test(phone)) {

            document.getElementById(
                "phoneError"
            ).innerHTML =
                "Số điện thoại phải gồm 10 hoặc 11 chữ số.";

            valid = false;
        }


        return valid;
    }

</script>


</body>

</html>