<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<!DOCTYPE html>
<html lang="vi">

<head>

<meta charset="UTF-8">

<title>Đăng nhập</title>

<style>
.error {
	color: red;
	font-size: 14px;
	margin-top: 5px;
}

.form-group {
	margin-bottom: 15px;
}

input {
	padding: 8px;
	width: 250px;
}

button {
	padding: 8px 20px;
	cursor: pointer;
}
</style>

</head>

<body>

	<h2>ĐĂNG NHẬP</h2>


	<!-- Thông báo từ Server -->

	<c:if test="${not empty alert}">

		<p style="color: red;">${alert}</p>

	</c:if>


	<form action="${pageContext.request.contextPath}/login" method="post"
		onsubmit="return validateLogin()">


		<!-- USERNAME -->

		<div class="form-group">

			<label> Username: </label> <br> <input type="text" id="username"
				name="username" value="${savedUsername}" minlength="3"
				maxlength="50" required>

			<div id="usernameError" class="error"></div>

		</div>


		<!-- PASSWORD -->

		<div class="form-group">

			<label> Password: </label> <br> <input type="password"
				id="password" name="password" minlength="6" maxlength="50" required>

			<div id="passwordError" class="error"></div>

		</div>


		<div class="form-group d-flex align-items-center">

			<input type="checkbox" id="remember" name="remember" value="on"
				style="width: auto; margin-right: 6px;"> <label
				for="remember"> Remember me </label>

		</div>


		<!-- BUTTON -->

		<button type="submit">Login</button>

		<br> <br> <a
			href="${pageContext.request.contextPath}/register"> Chưa có tài
			khoản? Đăng ký </a> <br> <br> <a
			href="${pageContext.request.contextPath}/forgot-password"> Quên
			mật khẩu? </a>

	</form>


	<script>
		function validateLogin() {

			let username = document.getElementById("username").value.trim();

			let password = document.getElementById("password").value;

			let usernameError = document.getElementById("usernameError");

			let passwordError = document.getElementById("passwordError");

			usernameError.innerHTML = "";
			passwordError.innerHTML = "";

			let isValid = true;

			// Kiểm tra Username

			if (username === "") {

				usernameError.innerHTML = "Username không được để trống.";

				isValid = false;

			} else if (username.length < 3) {

				usernameError.innerHTML = "Username phải có ít nhất 3 ký tự.";

				isValid = false;

			}

			// Kiểm tra Password

			if (password === "") {

				passwordError.innerHTML = "Password không được để trống.";

				isValid = false;

			} else if (password.length < 6) {

				passwordError.innerHTML = "Password phải có ít nhất 6 ký tự.";

				isValid = false;

			}

			return isValid;
		}
	</script>

</body>

</html>