<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">

<head>

    <meta charset="UTF-8">

    <title>Đăng ký tài khoản</title>

</head>

<body>

    <h2>ĐĂNG KÝ TÀI KHOẢN</h2>

    <c:if test="${not empty alert}">
        <p style="color:red;">
            ${alert}
        </p>
    </c:if>


    <form action="${pageContext.request.contextPath}/register"
          method="post"
          onsubmit="return validateRegister()">

        <!-- Username -->
        <div>

            <label>Username:</label>

            <input type="text"
                   id="username"
                   name="username"
                   required
                   minlength="3"
                   maxlength="50">

            <div id="usernameError"
                 style="color:red;">
            </div>

        </div>

        <br>


        <!-- Email -->
        <div>

            <label>Email:</label>

            <input type="email"
                   id="email"
                   name="email"
                   required>

            <div id="emailError"
                 style="color:red;">
            </div>

        </div>

        <br>


        <!-- Họ và tên -->
        <div>

            <label>Họ và tên:</label>

            <input type="text"
                   id="fullname"
                   name="fullname"
                   required
                   minlength="2"
                   maxlength="100">

            <div id="fullnameError"
                 style="color:red;">
            </div>

        </div>

        <br>


        <!-- Password -->
        <div>

            <label>Password:</label>

            <input type="password"
                   id="password"
                   name="password"
                   required
                   minlength="6"
                   maxlength="50">

            <div id="passwordError"
                 style="color:red;">
            </div>

        </div>

        <br>


        <!-- Số điện thoại -->
        <div>

            <label>Số điện thoại:</label>

            <input type="text"
                   id="phone"
                   name="phone">

            <div id="phoneError"
                 style="color:red;">
            </div>

        </div>

        <br>


        <!-- Button -->
        <button type="submit">
            Đăng ký
        </button>

    </form>


    <br>


    <a href="${pageContext.request.contextPath}/login">
        Đã có tài khoản? Đăng nhập
    </a>


    <script>

        function validateRegister() {

            let valid = true;

            let username =
                document.getElementById("username").value.trim();

            let email =
                document.getElementById("email").value.trim();

            let fullname =
                document.getElementById("fullname").value.trim();

            let password =
                document.getElementById("password").value;

            let phone =
                document.getElementById("phone").value.trim();


            // Xóa thông báo lỗi cũ

            document.getElementById("usernameError").innerHTML = "";

            document.getElementById("emailError").innerHTML = "";

            document.getElementById("fullnameError").innerHTML = "";

            document.getElementById("passwordError").innerHTML = "";

            document.getElementById("phoneError").innerHTML = "";


            // Kiểm tra Username

            if (username.length < 3 ||
                username.length > 50) {

                document.getElementById("usernameError").innerHTML =
                    "Username phải từ 3 đến 50 ký tự.";

                valid = false;
            }


            // Kiểm tra Email

            if (email === "") {

                document.getElementById("emailError").innerHTML =
                    "Email không được để trống.";

                valid = false;
            }


            // Kiểm tra Họ và tên

            if (fullname.length < 2 ||
                fullname.length > 100) {

                document.getElementById("fullnameError").innerHTML =
                    "Họ và tên phải từ 2 đến 100 ký tự.";

                valid = false;
            }


            // Kiểm tra Password

            if (password.length < 6 ||
                password.length > 50) {

                document.getElementById("passwordError").innerHTML =
                    "Password phải từ 6 đến 50 ký tự.";

                valid = false;
            }


            // Kiểm tra Số điện thoại

            if (phone !== "" &&
                !/^[0-9]{10,11}$/.test(phone)) {

                document.getElementById("phoneError").innerHTML =
                    "Số điện thoại phải gồm 10 hoặc 11 chữ số.";

                valid = false;
            }


            return valid;
        }

    </script>

</body>

</html>