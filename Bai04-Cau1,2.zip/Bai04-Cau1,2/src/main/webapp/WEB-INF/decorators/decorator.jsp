<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="vn.entity.User"%>

<!DOCTYPE html>

<html lang="vi">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap 5.3.3 -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
    </script>

    <title>
        <sitemesh:write property="title" />
    </title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background: #f5f7fb;
            color: #333;
        }

        .content {
            padding: 30px;
            min-height: calc(100vh - 65px);
        }

    </style>

    <sitemesh:write property="head" />

</head>

<body>

    <%

    User user = (User) session.getAttribute("account");

    %>


    <!-- ================= NAVBAR ================= -->

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">

        <div class="container-fluid px-4">

            <!-- Logo -->

            <a class="navbar-brand fw-bold"
               href="<%=request.getContextPath()%>/home">

                SHOPPING SERVICE

            </a>


            <!-- Mobile button -->

            <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarContent"
                aria-controls="navbarContent"
                aria-expanded="false"
                aria-label="Toggle navigation">

                <span class="navbar-toggler-icon"></span>

            </button>


            <!-- Navbar content -->

            <div class="collapse navbar-collapse" id="navbarContent">


                <!-- Menu bên trái -->

                <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                    <li class="nav-item">

                        <a class="nav-link"
                           href="<%=request.getContextPath()%>/home">

                            Trang chủ

                        </a>

                    </li>


                    <li class="nav-item">

                        <a class="nav-link"
                           href="<%=request.getContextPath()%>/product">

                            Sản phẩm

                        </a>

                    </li>

                </ul>


                <!-- User bên phải -->

                <%

                if (user != null) {

                %>


                <div class="dropdown">


                    <!-- User button -->

                    <button
                        class="btn btn-primary dropdown-toggle d-flex align-items-center gap-2"
                        type="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false">


                        <!-- Avatar -->

                        <%

                        if (user.getAvatar() != null
                                && !user.getAvatar().isBlank()) {

                        %>

                        <img
                            src="<%=request.getContextPath()%>/image?name=<%=user.getAvatar()%>"
                            alt="Avatar"
                            width="40"
                            height="40"
                            class="rounded-circle border border-white"
                            style="object-fit: cover;">

                        <%

                        } else {

                            String initial = "U";

                            if (user.getFullName() != null
                                    && !user.getFullName().isBlank()) {

                                initial = user.getFullName()
                                        .substring(0, 1)
                                        .toUpperCase();

                            } else if (user.getUserName() != null
                                    && !user.getUserName().isBlank()) {

                                initial = user.getUserName()
                                        .substring(0, 1)
                                        .toUpperCase();

                            }

                        %>


                        <span
                            class="rounded-circle bg-white text-primary fw-bold d-flex align-items-center justify-content-center"
                            style="width: 40px; height: 40px;">

                            <%=initial%>

                        </span>


                        <%

                        }

                        %>


                        <!-- User name -->

                        <span>

                            <%

                            if (user.getFullName() != null
                                    && !user.getFullName().isBlank()) {

                            %>

                                <%=user.getFullName()%>

                            <%

                            } else {

                            %>

                                <%=user.getUserName()%>

                            <%

                            }

                            %>

                        </span>

                    </button>


                    <!-- Dropdown menu -->

                    <ul class="dropdown-menu dropdown-menu-end">


                        <!-- Trang chủ -->

                        <li>

                            <a
                                class="dropdown-item"
                                href="<%=request.getContextPath()%>/home">

                                🏠 Trang chủ

                            </a>

                        </li>


                        <!-- Sản phẩm -->

                        <li>

                            <a
                                class="dropdown-item"
                                href="<%=request.getContextPath()%>/product">

                                🛍️ Sản phẩm

                            </a>

                        </li>


                        <!-- Hồ sơ -->

                        <li>

                            <a
                                class="dropdown-item"
                                href="<%=request.getContextPath()%>/profile">

                                👤 Hồ sơ cá nhân

                            </a>

                        </li>


                        <%

                        if (user.getRoleid() == 1) {

                        %>


                        <!-- Đường phân cách -->

                        <li>

                            <hr class="dropdown-divider">

                        </li>


                        <!-- Quản lý Products -->

                        <li>

                            <a
                                class="dropdown-item"
                                href="<%=request.getContextPath()%>/admin/product/list">

                                🛠️ Quản lý Products

                            </a>

                        </li>


                        <!-- Quản lý danh mục -->

                        <li>

                            <a
                                class="dropdown-item"
                                href="<%=request.getContextPath()%>/admin/category/list">

                                📂 Quản lý danh mục

                            </a>

                        </li>


                        <%

                        }

                        %>


                        <!-- Đường phân cách -->

                        <li>

                            <hr class="dropdown-divider">

                        </li>


                        <!-- Logout -->

                        <li>

                            <a
                                class="dropdown-item text-danger"
                                href="<%=request.getContextPath()%>/logout">

                                🚪 Đăng xuất

                            </a>

                        </li>

                    </ul>

                </div>


                <%

                } else {

                %>


                <!-- Chưa đăng nhập -->

                <a
                    class="btn btn-light"
                    href="<%=request.getContextPath()%>/login">

                    Đăng nhập

                </a>


                <%

                }

                %>

            </div>

        </div>

    </nav>


    <!-- ================= CONTENT ================= -->

    <div class="content">

        <sitemesh:write property="body" />

    </div>


</body>

</html>